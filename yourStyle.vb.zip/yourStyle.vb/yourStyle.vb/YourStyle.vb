﻿Imports System.Drawing.Text
Public Class FrmYourStyle

    'i used this video for reference https://www.youtube.com/watch?v=Lzc56H6MTbI&feature=youtu.be
    Dim FontSize As Integer = 8

    Private Sub FrmYourStyle_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        strQuarter = cmbQuarter.Text
        strVamp = cmbVamp.Text
        strEyestay = cmbEyestay.Text
        strLaces = cmbLaces.Text
        strHeel = cmbHeel.Text
        strHeelback = cmbHeelback.Text

        Dim MyFont As New InstalledFontCollection


        For Each FontName As FontFamily In MyFont.Families

            cmbFont.Items.Add(FontName.Name)

        Next
    End Sub

    Private Sub cmbFont_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbFont.SelectedIndexChanged
        'font size is equal to level of track bar
        FontSize = trkSize.Value
        'take the option selected from combo box and match the font style
        If cmbFontStyle.Text = "Regular" Then
            rchText.Font = New Font(cmbFont.Text, FontSize, FontStyle.Regular)
        ElseIf cmbFontStyle.Text = "Bold" Then
            rchText.Font = New Font(cmbFont.Text, FontSize, FontStyle.Bold)
        ElseIf cmbFontStyle.Text = "Italic" Then
            rchText.Font = New Font(cmbFont.Text, FontSize, FontStyle.Italic)
        End If

    End Sub

    Private Sub cmbFontStyle_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbFontStyle.SelectedIndexChanged
        FontSize = trkSize.Value

        If cmbFontStyle.Text = "Regular" Then
            rchText.Font = New Font(cmbFont.Text, FontSize, FontStyle.Regular)
        ElseIf cmbFontStyle.Text = "Bold" Then
            rchText.Font = New Font(cmbFont.Text, FontSize, FontStyle.Bold)
        ElseIf cmbFontStyle.Text = "Italic" Then
            rchText.Font = New Font(cmbFont.Text, FontSize, FontStyle.Italic)
        End If

    End Sub

    Private Sub trkSize_Scroll(sender As Object, e As EventArgs) Handles trkSize.Scroll

    End Sub

    Private Sub trkSize_ValueChanged(sender As Object, e As EventArgs) Handles trkSize.ValueChanged

        FontSize = trkSize.Value

        If cmbFontStyle.Text = "Regular" Then
            rchText.Font = New Font(cmbFont.Text, FontSize, FontStyle.Regular)
        ElseIf cmbFontStyle.Text = "Bold" Then
            rchText.Font = New Font(cmbFont.Text, FontSize, FontStyle.Bold)
        ElseIf cmbFontStyle.Text = "Italic" Then
            rchText.Font = New Font(cmbFont.Text, FontSize, FontStyle.Italic)
        End If

    End Sub

    Private Sub rchText_TextChanged(sender As Object, e As EventArgs) Handles rchText.TextChanged
        'if the length of teh streing in the text box is over ten add the extra pricing
        If rchText.Text.Length <= 10 Then
            dblCurrentPrice = dblCurrentPrice + 0.45
        ElseIf rchText.Text.Length > 10 Then
            dblCurrentPrice = dblCurrentPrice + 0.45 + ((rchText.Text.Length - 10) * 0.05)

        End If

    End Sub



    Private Sub btnCalculate_Click(sender As Object, e As EventArgs)
        'Calculations for model, customisation and logo

        'Model options
        If rdoClassic.Checked = True Then
            dblModel = dblClassic
        ElseIf rdoRetro.Checked = True Then
            dblModel = dblRetro
        ElseIf rdoVintage.Checked = True Then
            dblModel = dblVintage
        End If

        'Customisation options
        If cmbQuarter.Text = "White" = True Then
            dblQuarter = 0
        ElseIf cmbQuarter.Text = "White" = False Then
            dblQuarter = 8.99
        End If

        If cmbVamp.Text = "White" = True Then
            dblVamp = 0
        ElseIf cmbVamp.Text = "White" = False Then
            dblVamp = 14.99
        End If

        If cmbEyestay.Text = "White" = True Then
            dblEyestay = 0
        ElseIf cmbEyestay.Text = "White" = False Then
            dblEyestay = 5
        End If

        If cmbHeel.Text = "White" = True Then
            dblHeel = 0
        ElseIf cmbHeel.Text = "White" = True Then
            dblHeel = 4.99
        End If

        If cmbHeelback.Text = "White" = True Then
            dblHeelBack = 0
        ElseIf cmbHeelback.Text = "White" = False Then
            dblHeelBack = 6.49
        End If

        If cmbLaces.Text = "White" = True Then
            dblLaces = 0
        ElseIf cmbLaces.Text = "White" = False Then
            dblLaces = 4
        End If

        dblCustomisation = dblModel + dblQuarter + dblVamp + dblEyestay + dblLaces + dblHeel + dblHeelBack

        'Logo options
        If rdoYesLogo.Checked = True Then
            dblLogo = dblCustomisation * 0.18
        ElseIf rdoNoLogo.Checked = True Then
            dblLogo = 0
        End If






        'Overall calculation

        dblCustomisation = dblModel + dblQuarter + dblVamp + dblEyestay + dblLaces + dblHeel + dblHeelBack
        'if the corresponding radiobutton is checked the price will be added to the price variable
        'If rdoClassic.Checked = True Then
        'dblModel += dblClassic
        'ElseIf rdoRetro.Checked = True Then
        'dblModel += dblRetro
        'Else rdoVintage.Checked = True
        'dblModel += dblVintage
        'End If

        'FrmCustomisation.Show()
        'Me.Hide()
    End Sub

    Private Sub btnLogo_Click(sender As Object, e As EventArgs) Handles btnLogo.Click
        'used this video for reference  https://www.youtube.com/watch?v=qVEu3Z9CW84
        'using openfile dialog to allow the user to select their own logo 
        'changing the title of the window 
        OpenFileDialog1.Title = "Browse Logos"
        'open the files browser
        OpenFileDialog1.ShowDialog()
        lblFileSelected.Text = OpenFileDialog1.FileName
    End Sub


End Class
