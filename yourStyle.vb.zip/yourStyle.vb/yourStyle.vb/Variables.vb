﻿Module Variables
    'delcaring variables for shoe prices etc. 
    Public strQuarter As String
    Public strVamp As String
    Public strEyestay As String
    Public strLaces As String
    Public strHeel As String
    Public strHeelback As String

    Public dblModel As Double
    Public dblCustomisation As Double

    Public dblClassic As Double
    Public dblRetro As Double
    Public dblVintage As Double
    Public dblQuarter As Double
    Public dblVamp As Double
    Public dblEyestay As Double
    Public dblHeel As Double
    Public dblHeelBack As Double
    Public dblLaces As Double
    Public dblLogo As Double = 0.18
    Public dblText As Double = 0.45
    Public dblAddChar As Double = 0.05
    Public dblVat As Double = 0.23

    'declaring a variable to hold the current price of the shoe 
    Public dblCurrentPrice As Double

End Module
