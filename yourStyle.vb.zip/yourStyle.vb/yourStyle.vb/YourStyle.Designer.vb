﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmYourStyle
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.rdoClassic = New System.Windows.Forms.RadioButton()
        Me.rdoRetro = New System.Windows.Forms.RadioButton()
        Me.rdoVintage = New System.Windows.Forms.RadioButton()
        Me.cmbHeel = New System.Windows.Forms.ComboBox()
        Me.lblHeel = New System.Windows.Forms.Label()
        Me.cmbEyestay = New System.Windows.Forms.ComboBox()
        Me.lblEyestay = New System.Windows.Forms.Label()
        Me.cmbVamp = New System.Windows.Forms.ComboBox()
        Me.lblVamp = New System.Windows.Forms.Label()
        Me.lblQuarter = New System.Windows.Forms.Label()
        Me.cmbQuarter = New System.Windows.Forms.ComboBox()
        Me.grpSModel = New System.Windows.Forms.GroupBox()
        Me.grpColour = New System.Windows.Forms.GroupBox()
        Me.cmbLaces = New System.Windows.Forms.ComboBox()
        Me.lblLaces = New System.Windows.Forms.Label()
        Me.cmbHeelback = New System.Windows.Forms.ComboBox()
        Me.lblHeelback = New System.Windows.Forms.Label()
        Me.lblFileSelected = New System.Windows.Forms.Label()
        Me.btnLogo = New System.Windows.Forms.Button()
        Me.lblLogo = New System.Windows.Forms.Label()
        Me.grpLogo = New System.Windows.Forms.GroupBox()
        Me.pctLogo = New System.Windows.Forms.PictureBox()
        Me.grpLogo2 = New System.Windows.Forms.GroupBox()
        Me.rdoNoLogo = New System.Windows.Forms.RadioButton()
        Me.rdoYesLogo = New System.Windows.Forms.RadioButton()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.grpText = New System.Windows.Forms.GroupBox()
        Me.trkSize = New System.Windows.Forms.TrackBar()
        Me.lblStyle = New System.Windows.Forms.Label()
        Me.lblFont = New System.Windows.Forms.Label()
        Me.cmbFontStyle = New System.Windows.Forms.ComboBox()
        Me.cmbFont = New System.Windows.Forms.ComboBox()
        Me.rchText = New System.Windows.Forms.RichTextBox()
        Me.rdoNoText = New System.Windows.Forms.RadioButton()
        Me.rdoYesText = New System.Windows.Forms.RadioButton()
        Me.grpSModel.SuspendLayout()
        Me.grpColour.SuspendLayout()
        Me.grpLogo.SuspendLayout()
        CType(Me.pctLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpLogo2.SuspendLayout()
        Me.grpText.SuspendLayout()
        CType(Me.trkSize, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'rdoClassic
        '
        Me.rdoClassic.AutoSize = True
        Me.rdoClassic.Location = New System.Drawing.Point(38, 47)
        Me.rdoClassic.Margin = New System.Windows.Forms.Padding(4)
        Me.rdoClassic.Name = "rdoClassic"
        Me.rdoClassic.Size = New System.Drawing.Size(131, 21)
        Me.rdoClassic.TabIndex = 0
        Me.rdoClassic.TabStop = True
        Me.rdoClassic.Text = "Classic (€54.99)"
        Me.rdoClassic.UseVisualStyleBackColor = True
        '
        'rdoRetro
        '
        Me.rdoRetro.AutoSize = True
        Me.rdoRetro.Location = New System.Drawing.Point(38, 90)
        Me.rdoRetro.Margin = New System.Windows.Forms.Padding(4)
        Me.rdoRetro.Name = "rdoRetro"
        Me.rdoRetro.Size = New System.Drawing.Size(122, 21)
        Me.rdoRetro.TabIndex = 1
        Me.rdoRetro.TabStop = True
        Me.rdoRetro.Text = "Retro (€49.50)"
        Me.rdoRetro.UseVisualStyleBackColor = True
        '
        'rdoVintage
        '
        Me.rdoVintage.AutoSize = True
        Me.rdoVintage.Location = New System.Drawing.Point(38, 131)
        Me.rdoVintage.Margin = New System.Windows.Forms.Padding(4)
        Me.rdoVintage.Name = "rdoVintage"
        Me.rdoVintage.Size = New System.Drawing.Size(135, 21)
        Me.rdoVintage.TabIndex = 2
        Me.rdoVintage.TabStop = True
        Me.rdoVintage.Text = "Vintage (€44.99)"
        Me.rdoVintage.UseVisualStyleBackColor = True
        '
        'cmbHeel
        '
        Me.cmbHeel.FormattingEnabled = True
        Me.cmbHeel.Items.AddRange(New Object() {"White", "Red", "Blue", "Green", "Yellow", "Dark Grey", "Light Grey", "Black"})
        Me.cmbHeel.Location = New System.Drawing.Point(113, 203)
        Me.cmbHeel.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbHeel.Name = "cmbHeel"
        Me.cmbHeel.Size = New System.Drawing.Size(160, 24)
        Me.cmbHeel.TabIndex = 20
        Me.cmbHeel.Text = "White"
        '
        'lblHeel
        '
        Me.lblHeel.AutoSize = True
        Me.lblHeel.Location = New System.Drawing.Point(46, 203)
        Me.lblHeel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblHeel.Name = "lblHeel"
        Me.lblHeel.Size = New System.Drawing.Size(41, 17)
        Me.lblHeel.TabIndex = 19
        Me.lblHeel.Text = "Heel:"
        '
        'cmbEyestay
        '
        Me.cmbEyestay.FormattingEnabled = True
        Me.cmbEyestay.Items.AddRange(New Object() {"White", "Red", "Blue", "Green", "Yellow", "Dark Grey", "Light Grey", "Black"})
        Me.cmbEyestay.Location = New System.Drawing.Point(113, 115)
        Me.cmbEyestay.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbEyestay.Name = "cmbEyestay"
        Me.cmbEyestay.Size = New System.Drawing.Size(160, 24)
        Me.cmbEyestay.TabIndex = 18
        Me.cmbEyestay.Text = "White"
        '
        'lblEyestay
        '
        Me.lblEyestay.AutoSize = True
        Me.lblEyestay.Location = New System.Drawing.Point(25, 119)
        Me.lblEyestay.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblEyestay.Name = "lblEyestay"
        Me.lblEyestay.Size = New System.Drawing.Size(62, 17)
        Me.lblEyestay.TabIndex = 17
        Me.lblEyestay.Text = "Eyestay:"
        '
        'cmbVamp
        '
        Me.cmbVamp.FormattingEnabled = True
        Me.cmbVamp.Items.AddRange(New Object() {"White", "Red ", "Blue", "Green", "Yellow", "Dark Grey", "Light Grey", "Black"})
        Me.cmbVamp.Location = New System.Drawing.Point(113, 71)
        Me.cmbVamp.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbVamp.Name = "cmbVamp"
        Me.cmbVamp.Size = New System.Drawing.Size(160, 24)
        Me.cmbVamp.TabIndex = 15
        Me.cmbVamp.Text = "White"
        '
        'lblVamp
        '
        Me.lblVamp.AutoSize = True
        Me.lblVamp.Location = New System.Drawing.Point(39, 76)
        Me.lblVamp.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblVamp.Name = "lblVamp"
        Me.lblVamp.Size = New System.Drawing.Size(48, 17)
        Me.lblVamp.TabIndex = 14
        Me.lblVamp.Text = "Vamp:"
        '
        'lblQuarter
        '
        Me.lblQuarter.AutoSize = True
        Me.lblQuarter.Location = New System.Drawing.Point(26, 26)
        Me.lblQuarter.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblQuarter.Name = "lblQuarter"
        Me.lblQuarter.Size = New System.Drawing.Size(61, 17)
        Me.lblQuarter.TabIndex = 13
        Me.lblQuarter.Text = "Quarter:"
        '
        'cmbQuarter
        '
        Me.cmbQuarter.FormattingEnabled = True
        Me.cmbQuarter.Items.AddRange(New Object() {"White ", "Red", "Blue", "Green", "Yellow", "Dark Grey", "Light Grey", "Black"})
        Me.cmbQuarter.Location = New System.Drawing.Point(113, 23)
        Me.cmbQuarter.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbQuarter.Name = "cmbQuarter"
        Me.cmbQuarter.Size = New System.Drawing.Size(160, 24)
        Me.cmbQuarter.TabIndex = 12
        Me.cmbQuarter.Text = "White "
        '
        'grpSModel
        '
        Me.grpSModel.Controls.Add(Me.rdoVintage)
        Me.grpSModel.Controls.Add(Me.rdoRetro)
        Me.grpSModel.Controls.Add(Me.rdoClassic)
        Me.grpSModel.Location = New System.Drawing.Point(41, 24)
        Me.grpSModel.Name = "grpSModel"
        Me.grpSModel.Size = New System.Drawing.Size(196, 186)
        Me.grpSModel.TabIndex = 22
        Me.grpSModel.TabStop = False
        Me.grpSModel.Text = "Shoe Model"
        '
        'grpColour
        '
        Me.grpColour.Controls.Add(Me.cmbLaces)
        Me.grpColour.Controls.Add(Me.lblLaces)
        Me.grpColour.Controls.Add(Me.cmbHeelback)
        Me.grpColour.Controls.Add(Me.lblHeelback)
        Me.grpColour.Controls.Add(Me.cmbHeel)
        Me.grpColour.Controls.Add(Me.lblHeel)
        Me.grpColour.Controls.Add(Me.cmbEyestay)
        Me.grpColour.Controls.Add(Me.lblEyestay)
        Me.grpColour.Controls.Add(Me.cmbVamp)
        Me.grpColour.Controls.Add(Me.lblVamp)
        Me.grpColour.Controls.Add(Me.lblQuarter)
        Me.grpColour.Controls.Add(Me.cmbQuarter)
        Me.grpColour.Location = New System.Drawing.Point(41, 227)
        Me.grpColour.Name = "grpColour"
        Me.grpColour.Size = New System.Drawing.Size(285, 301)
        Me.grpColour.TabIndex = 23
        Me.grpColour.TabStop = False
        Me.grpColour.Text = "Colour Options"
        '
        'cmbLaces
        '
        Me.cmbLaces.FormattingEnabled = True
        Me.cmbLaces.Items.AddRange(New Object() {"White", "Red", "Blue", "Green", "Yellow", "Dark Grey", "Light Grey", "Black"})
        Me.cmbLaces.Location = New System.Drawing.Point(113, 164)
        Me.cmbLaces.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbLaces.Name = "cmbLaces"
        Me.cmbLaces.Size = New System.Drawing.Size(160, 24)
        Me.cmbLaces.TabIndex = 24
        Me.cmbLaces.Text = "White"
        '
        'lblLaces
        '
        Me.lblLaces.AutoSize = True
        Me.lblLaces.Location = New System.Drawing.Point(37, 164)
        Me.lblLaces.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblLaces.Name = "lblLaces"
        Me.lblLaces.Size = New System.Drawing.Size(50, 17)
        Me.lblLaces.TabIndex = 23
        Me.lblLaces.Text = "Laces:"
        '
        'cmbHeelback
        '
        Me.cmbHeelback.FormattingEnabled = True
        Me.cmbHeelback.Items.AddRange(New Object() {"White", "Red", "Blue", "Yellow", "Dark Grey", "Light Grey", "Black"})
        Me.cmbHeelback.Location = New System.Drawing.Point(113, 247)
        Me.cmbHeelback.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbHeelback.Name = "cmbHeelback"
        Me.cmbHeelback.Size = New System.Drawing.Size(160, 24)
        Me.cmbHeelback.TabIndex = 22
        Me.cmbHeelback.Text = "White"
        '
        'lblHeelback
        '
        Me.lblHeelback.AutoSize = True
        Me.lblHeelback.Location = New System.Drawing.Point(16, 250)
        Me.lblHeelback.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblHeelback.Name = "lblHeelback"
        Me.lblHeelback.Size = New System.Drawing.Size(71, 17)
        Me.lblHeelback.TabIndex = 21
        Me.lblHeelback.Text = "Heelback:"
        '
        'lblFileSelected
        '
        Me.lblFileSelected.AutoSize = True
        Me.lblFileSelected.Location = New System.Drawing.Point(32, 167)
        Me.lblFileSelected.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblFileSelected.Name = "lblFileSelected"
        Me.lblFileSelected.Size = New System.Drawing.Size(105, 17)
        Me.lblFileSelected.TabIndex = 27
        Me.lblFileSelected.Text = "No file selected"
        '
        'btnLogo
        '
        Me.btnLogo.Location = New System.Drawing.Point(239, 96)
        Me.btnLogo.Margin = New System.Windows.Forms.Padding(4)
        Me.btnLogo.Name = "btnLogo"
        Me.btnLogo.Size = New System.Drawing.Size(100, 28)
        Me.btnLogo.TabIndex = 26
        Me.btnLogo.Text = "Browse Files"
        Me.btnLogo.UseVisualStyleBackColor = True
        '
        'lblLogo
        '
        Me.lblLogo.AutoSize = True
        Me.lblLogo.Location = New System.Drawing.Point(32, 96)
        Me.lblLogo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblLogo.Name = "lblLogo"
        Me.lblLogo.Size = New System.Drawing.Size(139, 17)
        Me.lblLogo.TabIndex = 25
        Me.lblLogo.Text = "Add Your Own Logo:"
        '
        'grpLogo
        '
        Me.grpLogo.Controls.Add(Me.pctLogo)
        Me.grpLogo.Controls.Add(Me.grpLogo2)
        Me.grpLogo.Controls.Add(Me.lblLogo)
        Me.grpLogo.Controls.Add(Me.lblFileSelected)
        Me.grpLogo.Controls.Add(Me.btnLogo)
        Me.grpLogo.Location = New System.Drawing.Point(344, 24)
        Me.grpLogo.Name = "grpLogo"
        Me.grpLogo.Size = New System.Drawing.Size(353, 504)
        Me.grpLogo.TabIndex = 28
        Me.grpLogo.TabStop = False
        Me.grpLogo.Text = "Logo"
        '
        'pctLogo
        '
        Me.pctLogo.Location = New System.Drawing.Point(41, 237)
        Me.pctLogo.Name = "pctLogo"
        Me.pctLogo.Size = New System.Drawing.Size(270, 236)
        Me.pctLogo.TabIndex = 30
        Me.pctLogo.TabStop = False
        '
        'grpLogo2
        '
        Me.grpLogo2.Controls.Add(Me.rdoNoLogo)
        Me.grpLogo2.Controls.Add(Me.rdoYesLogo)
        Me.grpLogo2.Location = New System.Drawing.Point(22, 31)
        Me.grpLogo2.Name = "grpLogo2"
        Me.grpLogo2.Size = New System.Drawing.Size(201, 62)
        Me.grpLogo2.TabIndex = 29
        Me.grpLogo2.TabStop = False
        Me.grpLogo2.Text = "Do you want to add a Logo?"
        '
        'rdoNoLogo
        '
        Me.rdoNoLogo.AutoSize = True
        Me.rdoNoLogo.Location = New System.Drawing.Point(111, 21)
        Me.rdoNoLogo.Name = "rdoNoLogo"
        Me.rdoNoLogo.Size = New System.Drawing.Size(47, 21)
        Me.rdoNoLogo.TabIndex = 29
        Me.rdoNoLogo.TabStop = True
        Me.rdoNoLogo.Text = "No"
        Me.rdoNoLogo.UseVisualStyleBackColor = True
        '
        'rdoYesLogo
        '
        Me.rdoYesLogo.AutoSize = True
        Me.rdoYesLogo.Location = New System.Drawing.Point(22, 21)
        Me.rdoYesLogo.Name = "rdoYesLogo"
        Me.rdoYesLogo.Size = New System.Drawing.Size(53, 21)
        Me.rdoYesLogo.TabIndex = 28
        Me.rdoYesLogo.TabStop = True
        Me.rdoYesLogo.Text = "Yes"
        Me.rdoYesLogo.UseVisualStyleBackColor = True
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(480, 609)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.btnCalculate.TabIndex = 29
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'grpText
        '
        Me.grpText.Controls.Add(Me.trkSize)
        Me.grpText.Controls.Add(Me.lblStyle)
        Me.grpText.Controls.Add(Me.lblFont)
        Me.grpText.Controls.Add(Me.cmbFontStyle)
        Me.grpText.Controls.Add(Me.cmbFont)
        Me.grpText.Controls.Add(Me.rchText)
        Me.grpText.Controls.Add(Me.rdoNoText)
        Me.grpText.Controls.Add(Me.rdoYesText)
        Me.grpText.Location = New System.Drawing.Point(717, 24)
        Me.grpText.Name = "grpText"
        Me.grpText.Size = New System.Drawing.Size(445, 493)
        Me.grpText.TabIndex = 30
        Me.grpText.TabStop = False
        Me.grpText.Text = "Add Text?"
        '
        'trkSize
        '
        Me.trkSize.Location = New System.Drawing.Point(27, 171)
        Me.trkSize.Name = "trkSize"
        Me.trkSize.Size = New System.Drawing.Size(412, 56)
        Me.trkSize.TabIndex = 7
        '
        'lblStyle
        '
        Me.lblStyle.AutoSize = True
        Me.lblStyle.Location = New System.Drawing.Point(72, 134)
        Me.lblStyle.Name = "lblStyle"
        Me.lblStyle.Size = New System.Drawing.Size(75, 17)
        Me.lblStyle.TabIndex = 6
        Me.lblStyle.Text = "Font Style:"
        '
        'lblFont
        '
        Me.lblFont.AutoSize = True
        Me.lblFont.Location = New System.Drawing.Point(107, 87)
        Me.lblFont.Name = "lblFont"
        Me.lblFont.Size = New System.Drawing.Size(40, 17)
        Me.lblFont.TabIndex = 5
        Me.lblFont.Text = "Font:"
        '
        'cmbFontStyle
        '
        Me.cmbFontStyle.FormattingEnabled = True
        Me.cmbFontStyle.Location = New System.Drawing.Point(163, 131)
        Me.cmbFontStyle.Name = "cmbFontStyle"
        Me.cmbFontStyle.Size = New System.Drawing.Size(121, 24)
        Me.cmbFontStyle.TabIndex = 4
        '
        'cmbFont
        '
        Me.cmbFont.FormattingEnabled = True
        Me.cmbFont.Location = New System.Drawing.Point(163, 87)
        Me.cmbFont.Name = "cmbFont"
        Me.cmbFont.Size = New System.Drawing.Size(121, 24)
        Me.cmbFont.TabIndex = 3
        '
        'rchText
        '
        Me.rchText.Location = New System.Drawing.Point(17, 233)
        Me.rchText.Name = "rchText"
        Me.rchText.Size = New System.Drawing.Size(422, 240)
        Me.rchText.TabIndex = 2
        Me.rchText.Text = ""
        '
        'rdoNoText
        '
        Me.rdoNoText.AutoSize = True
        Me.rdoNoText.Location = New System.Drawing.Point(240, 42)
        Me.rdoNoText.Name = "rdoNoText"
        Me.rdoNoText.Size = New System.Drawing.Size(47, 21)
        Me.rdoNoText.TabIndex = 1
        Me.rdoNoText.TabStop = True
        Me.rdoNoText.Text = "No"
        Me.rdoNoText.UseVisualStyleBackColor = True
        '
        'rdoYesText
        '
        Me.rdoYesText.AutoSize = True
        Me.rdoYesText.Location = New System.Drawing.Point(54, 42)
        Me.rdoYesText.Name = "rdoYesText"
        Me.rdoYesText.Size = New System.Drawing.Size(53, 21)
        Me.rdoYesText.TabIndex = 0
        Me.rdoYesText.TabStop = True
        Me.rdoYesText.Text = "Yes"
        Me.rdoYesText.UseVisualStyleBackColor = True
        '
        'FrmYourStyle
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1174, 665)
        Me.Controls.Add(Me.grpText)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.grpColour)
        Me.Controls.Add(Me.grpLogo)
        Me.Controls.Add(Me.grpSModel)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "FrmYourStyle"
        Me.Text = "Your Style"
        Me.grpSModel.ResumeLayout(False)
        Me.grpSModel.PerformLayout()
        Me.grpColour.ResumeLayout(False)
        Me.grpColour.PerformLayout()
        Me.grpLogo.ResumeLayout(False)
        Me.grpLogo.PerformLayout()
        CType(Me.pctLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpLogo2.ResumeLayout(False)
        Me.grpLogo2.PerformLayout()
        Me.grpText.ResumeLayout(False)
        Me.grpText.PerformLayout()
        CType(Me.trkSize, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents rdoClassic As RadioButton
    Friend WithEvents rdoRetro As RadioButton
    Friend WithEvents rdoVintage As RadioButton
    Friend WithEvents cmbHeel As ComboBox
    Friend WithEvents lblHeel As Label
    Friend WithEvents cmbEyestay As ComboBox
    Friend WithEvents lblEyestay As Label
    Friend WithEvents cmbVamp As ComboBox
    Friend WithEvents lblVamp As Label
    Friend WithEvents lblQuarter As Label
    Friend WithEvents cmbQuarter As ComboBox
    Friend WithEvents grpSModel As GroupBox
    Friend WithEvents grpColour As GroupBox
    Friend WithEvents cmbLaces As ComboBox
    Friend WithEvents lblLaces As Label
    Friend WithEvents cmbHeelback As ComboBox
    Friend WithEvents lblHeelback As Label
    Friend WithEvents lblFileSelected As Label
    Friend WithEvents btnLogo As Button
    Friend WithEvents lblLogo As Label
    Friend WithEvents grpLogo As GroupBox
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents btnCalculate As Button
    Friend WithEvents grpLogo2 As GroupBox
    Friend WithEvents rdoYesLogo As RadioButton
    Friend WithEvents rdoNoLogo As RadioButton
    Friend WithEvents pctLogo As PictureBox
    Friend WithEvents grpText As GroupBox
    Friend WithEvents rdoNoText As RadioButton
    Friend WithEvents rdoYesText As RadioButton
    Friend WithEvents rchText As RichTextBox
    Friend WithEvents trkSize As TrackBar
    Friend WithEvents lblStyle As Label
    Friend WithEvents lblFont As Label
    Friend WithEvents cmbFontStyle As ComboBox
    Friend WithEvents cmbFont As ComboBox
End Class
