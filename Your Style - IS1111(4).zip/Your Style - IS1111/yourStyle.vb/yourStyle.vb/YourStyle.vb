﻿Imports System.Drawing.Text
Public Class frmYourStyle

    'i used this video for reference https://www.youtube.com/watch?v=Lzc56H6MTbI&feature=youtu.be for adding customised text
    Dim FontSize As Integer = 8

    Private Sub FrmYourStyle_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        strQuarter = cmbQuarter.Text
        strVamp = cmbVamp.Text
        strEyestay = cmbEyestay.Text
        strLaces = cmbLaces.Text
        strHeel = cmbHeel.Text
        strHeelback = cmbHeelback.Text

        Dim MyFont As New InstalledFontCollection


        For Each FontName As FontFamily In MyFont.Families

            cmbFont.Items.Add(FontName.Name)

        Next
    End Sub

    Private Sub cmbFont_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbFont.SelectedIndexChanged
        'font size is equal to level of track bar
        FontSize = trkSize.Value
        'take the option selected from combo box and match the font style
        If cmbFontStyle.Text = "Regular" Then
            rchText.Font = New Font(cmbFont.Text, FontSize, FontStyle.Regular)
        ElseIf cmbFontStyle.Text = "Bold" Then
            rchText.Font = New Font(cmbFont.Text, FontSize, FontStyle.Bold)
        ElseIf cmbFontStyle.Text = "Italic" Then
            rchText.Font = New Font(cmbFont.Text, FontSize, FontStyle.Italic)
        End If

    End Sub

    Private Sub cmbFontStyle_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbFontStyle.SelectedIndexChanged
        FontSize = trkSize.Value
        'here customisation for text
        If cmbFontStyle.Text = "Regular" Then
            rchText.Font = New Font(cmbFont.Text, FontSize, FontStyle.Regular)
        ElseIf cmbFontStyle.Text = "Bold" Then
            rchText.Font = New Font(cmbFont.Text, FontSize, FontStyle.Bold)
        ElseIf cmbFontStyle.Text = "Italic" Then
            rchText.Font = New Font(cmbFont.Text, FontSize, FontStyle.Italic)
        End If

    End Sub

    Private Sub trkSize_Scroll(sender As Object, e As EventArgs) Handles trkSize.Scroll

    End Sub

    Private Sub trkSize_ValueChanged(sender As Object, e As EventArgs) Handles trkSize.ValueChanged

        FontSize = trkSize.Value

        If cmbFontStyle.Text = "Regular" Then
            rchText.Font = New Font(cmbFont.Text, FontSize, FontStyle.Regular)
        ElseIf cmbFontStyle.Text = "Bold" Then
            rchText.Font = New Font(cmbFont.Text, FontSize, FontStyle.Bold)
        ElseIf cmbFontStyle.Text = "Italic" Then
            rchText.Font = New Font(cmbFont.Text, FontSize, FontStyle.Italic)
        End If

    End Sub





    Private Sub btnCalculate_Click(sender As Object, e As EventArgs)


        txtSubTotal.Text = (dblCustomisation)
    End Sub

    Private Sub btnLogo_Click(sender As Object, e As EventArgs) Handles btnLogo.Click
        'used this video for reference  https://www.youtube.com/watch?v=qVEu3Z9CW84
        'using openfile dialog to allow the user to select their own logo 
        'changing the title of the window 
        OpenFileDialog1.Title = "Browse Logos"
        'open the files browser
        OpenFileDialog1.ShowDialog()
        lblFileSelected.Text = OpenFileDialog1.FileName
    End Sub

    Private Sub btnCalculate_Click_1(sender As Object, e As EventArgs) Handles btnCalculate.Click

        frmPayment.lstBreakdown.Items.Add("                Breakdown of Prices")

        'Calculations for model, customisation and logo, including how it's filling into price breakdown(lol) - including formatting and adding to list box on next form
        frmPayment.lstBreakdown.Items.Add("")
        frmPayment.lstBreakdown.Items.Add("")

        'Model options
        If rdoClassic.Checked = True Then
            dblModel = dblClassic
            frmPayment.lstBreakdown.Items.Add("Shoe Model: Classic " & "€" & dblClassic)
        ElseIf rdoRetro.Checked = True Then
            dblModel = dblRetro
            frmPayment.lstBreakdown.Items.Add("Shoe Model: Retro " & "€" & dblRetro)
        ElseIf rdoVintage.Checked = True Then
            dblModel = dblVintage
            frmPayment.lstBreakdown.Items.Add("Shoe Model: Vintage " & "€" & dblVintage)
        End If
        frmPayment.lstBreakdown.Items.Add("Shoe Size: " & cmbSize.Text)
        frmPayment.lstBreakdown.Items.Add("")
        frmPayment.lstBreakdown.Items.Add("                Customisation Options")
        frmPayment.lstBreakdown.Items.Add("")

        'Customisation options
        If cmbQuarter.Text = "White" = True Then
            dblQuarter = 0
            frmPayment.lstBreakdown.Items.Add("Quarter Colour: " & cmbQuarter.Text & "@ " & "€" & dblQuarter)
        ElseIf cmbQuarter.Text = "White" = False Then
            dblQuarter = 8.99
            frmPayment.lstBreakdown.Items.Add("Quarter Colour: " & cmbQuarter.Text & "@ " & "€" & dblQuarter)
        End If

        If cmbVamp.Text = "White" = True Then
            dblVamp = 0
            frmPayment.lstBreakdown.Items.Add("Vamp Colour: " & cmbVamp.Text & "@ " & "€" & dblVamp)
        ElseIf cmbVamp.Text = "White" = False Then
            dblVamp = 14.99
            frmPayment.lstBreakdown.Items.Add("Vamp Colour: " & cmbVamp.Text & "@ " & "€" & dblVamp)
        End If

        If cmbEyestay.Text = "White" = True Then
            dblEyestay = 0
            frmPayment.lstBreakdown.Items.Add("Eyestay Colour: " & cmbEyestay.Text & "@ " & "€" & dblEyestay)
        ElseIf cmbEyestay.Text = "White" = False Then
            dblEyestay = 5
            frmPayment.lstBreakdown.Items.Add("Eyestay Colour: " & cmbEyestay.Text & "@ " & "€" & dblEyestay)
        End If

        If cmbHeel.Text = "White" = True Then
            dblHeel = 0
            frmPayment.lstBreakdown.Items.Add("Heel Colour: " & cmbHeel.Text & "@ " & "€" & dblHeel)
        ElseIf cmbHeel.Text = "White" = False Then
            dblHeel = 4.99
            frmPayment.lstBreakdown.Items.Add("Heel Colour: " & cmbHeel.Text & "@ " & "€" & dblHeel)
        End If

        If cmbHeelback.Text = "White" = True Then
            dblHeelBack = 0
            frmPayment.lstBreakdown.Items.Add("Heelback Colour: " & cmbHeelback.Text & "@ " & "€" & dblHeelBack)
        ElseIf cmbHeelback.Text = "White" = False Then
            dblHeelBack = 6.49
            frmPayment.lstBreakdown.Items.Add("Heelback Colour: " & cmbHeelback.Text & "@ " & "€" & dblHeelBack)
        End If

        If cmbLaces.Text = "White" = True Then
            dblLaces = 0
            frmPayment.lstBreakdown.Items.Add("Laces Colour: " & cmbLaces.Text & "@ " & "€" & dblLaces)
        ElseIf cmbLaces.Text = "White" = False Then
            dblLaces = 4
            frmPayment.lstBreakdown.Items.Add("Laces Colour: " & cmbLaces.Text & "@ " & "€" & dblLaces)
        End If

        'Logo options
        If rdoYesLogo.Checked = True Then
            dblLogo = dblCustomisation * 0.18
            frmPayment.lstBreakdown.Items.Add("Logo Added " & "@ " & "€" & dblLogo)
        ElseIf rdoNoLogo.Checked = True Then
            dblLogo = 0
            frmPayment.lstBreakdown.Items.Add("Logo: No logo added.")
        End If

        'Customising text 
        If rdoYesText.Checked = True Then

            'if the length of the string in the text box is over ten characters, add the extra pricing
            If rchText.Text.Length <= 10 Then
                dblText = 0.45
            ElseIf rchText.Text.Length > 10 Then
                dblText = 0.45 + ((rchText.Text.Length - 10) * 0.05)

            End If
            frmPayment.lstBreakdown.Items.Add("Text added: " & "€" & dblText)
        ElseIf rdoNoText.Checked = True Then
            dblText = 0
            frmPayment.lstBreakdown.Items.Add("Text: No text added.")
        End If

        'using variable to claculate customisations so that the calculation for dbllogo can be done
        dblCustomisation = dblModel + dblQuarter + dblVamp + dblEyestay + dblLaces + dblHeel + dblHeelBack

        'inserting separation for price breakdown


        'calculation for all subtotal which includes logo and text but doesn't include vat
        dblSubTotal = dblCustomisation + dblLogo + dblText

        'displaying subtotal in textbox once calculate is clicked
        txtSubTotal.Text = dblSubTotal

        'calculation of tax'
        dblVat = dblSubTotal * 0.23
        dblTotal = 2 * (dblSubTotal + dblVat)
        frmPayment.lstBreakdown.Items.Add("=====================================")
        'inserting subtotal costs and tax into the price breakdown
        frmPayment.lstBreakdown.Items.Add("Subtotal: " & "€" & dblSubTotal & " per shoe")
        frmPayment.lstBreakdown.Items.Add("V.A.T. @ 23% = " & dblVat)
        frmPayment.lstBreakdown.Items.Add("Total: " & "€" & dblTotal)

    End Sub

    Private Sub rdoYesLogo_CheckedChanged(sender As Object, e As EventArgs) Handles rdoYesLogo.CheckedChanged
        lblLogo.Visible = True
        btnLogo.Visible = True

        lblFileSelected.Visible = True
        pctLogo.Visible = True

    End Sub

    Private Sub rdoNoLogo_CheckedChanged(sender As Object, e As EventArgs) Handles rdoNoLogo.CheckedChanged
        lblLogo.Visible = False
        btnLogo.Visible = False

        lblFileSelected.Visible = False
        pctLogo.Visible = False

    End Sub

    'not allowing user to enter choices if no is selected
    Private Sub rdoNoText_CheckedChanged(sender As Object, e As EventArgs) Handles rdoNoText.CheckedChanged
        rchText.Visible = False
        trkSize.Visible = False

        lblFont.Visible = False
        cmbFont.Visible = False

        lblFontStyle.Visible = False
        cmbFontStyle.Visible = False
    End Sub

    Private Sub rdoYesText_CheckedChanged(sender As Object, e As EventArgs) Handles rdoYesText.CheckedChanged
        rchText.Visible = True
        trkSize.Visible = True
        lblFont.Visible = True
        cmbFont.Visible = True

        lblFontStyle.Visible = True
        cmbFontStyle.Visible = True

    End Sub

    Private Sub btnProceed_Click(sender As Object, e As EventArgs) Handles btnProceed.Click
        Me.Hide()
        frmPayment.Show()

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        frmPayment.lstBreakdown.Items.Clear()
        Me.Close()
        frmLogin.Show()
    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        frmPayment.lstBreakdown.Items.Clear()
        Me.Close()
        frmHome.Show()


    End Sub
End Class
