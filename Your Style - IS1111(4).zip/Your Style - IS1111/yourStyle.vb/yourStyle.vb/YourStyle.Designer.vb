﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmYourStyle
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmYourStyle))
        Me.rdoClassic = New System.Windows.Forms.RadioButton()
        Me.rdoRetro = New System.Windows.Forms.RadioButton()
        Me.rdoVintage = New System.Windows.Forms.RadioButton()
        Me.cmbHeel = New System.Windows.Forms.ComboBox()
        Me.lblHeel = New System.Windows.Forms.Label()
        Me.cmbEyestay = New System.Windows.Forms.ComboBox()
        Me.lblEyestay = New System.Windows.Forms.Label()
        Me.cmbVamp = New System.Windows.Forms.ComboBox()
        Me.lblVamp = New System.Windows.Forms.Label()
        Me.lblQuarter = New System.Windows.Forms.Label()
        Me.cmbQuarter = New System.Windows.Forms.ComboBox()
        Me.grpSModel = New System.Windows.Forms.GroupBox()
        Me.cmbSize = New System.Windows.Forms.ComboBox()
        Me.lblSize = New System.Windows.Forms.Label()
        Me.grpColour = New System.Windows.Forms.GroupBox()
        Me.cmbLaces = New System.Windows.Forms.ComboBox()
        Me.lblLaces = New System.Windows.Forms.Label()
        Me.cmbHeelback = New System.Windows.Forms.ComboBox()
        Me.lblHeelback = New System.Windows.Forms.Label()
        Me.lblFileSelected = New System.Windows.Forms.Label()
        Me.btnLogo = New System.Windows.Forms.Button()
        Me.lblLogo = New System.Windows.Forms.Label()
        Me.grpLogo = New System.Windows.Forms.GroupBox()
        Me.pctLogo = New System.Windows.Forms.PictureBox()
        Me.grpLogo2 = New System.Windows.Forms.GroupBox()
        Me.rdoNoLogo = New System.Windows.Forms.RadioButton()
        Me.rdoYesLogo = New System.Windows.Forms.RadioButton()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.grpText = New System.Windows.Forms.GroupBox()
        Me.trkSize = New System.Windows.Forms.TrackBar()
        Me.lblFontStyle = New System.Windows.Forms.Label()
        Me.lblFont = New System.Windows.Forms.Label()
        Me.cmbFontStyle = New System.Windows.Forms.ComboBox()
        Me.cmbFont = New System.Windows.Forms.ComboBox()
        Me.rchText = New System.Windows.Forms.RichTextBox()
        Me.rdoNoText = New System.Windows.Forms.RadioButton()
        Me.rdoYesText = New System.Windows.Forms.RadioButton()
        Me.txtSubtotal = New System.Windows.Forms.TextBox()
        Me.lblSubTotal = New System.Windows.Forms.Label()
        Me.btnProceed = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnHome = New System.Windows.Forms.Button()
        Me.grpSModel.SuspendLayout()
        Me.grpColour.SuspendLayout()
        Me.grpLogo.SuspendLayout()
        CType(Me.pctLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpLogo2.SuspendLayout()
        Me.grpText.SuspendLayout()
        CType(Me.trkSize, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'rdoClassic
        '
        Me.rdoClassic.AutoSize = True
        Me.rdoClassic.Location = New System.Drawing.Point(21, 35)
        Me.rdoClassic.Margin = New System.Windows.Forms.Padding(4)
        Me.rdoClassic.Name = "rdoClassic"
        Me.rdoClassic.Size = New System.Drawing.Size(136, 22)
        Me.rdoClassic.TabIndex = 0
        Me.rdoClassic.TabStop = True
        Me.rdoClassic.Text = "Classic (€54.99)"
        Me.rdoClassic.UseVisualStyleBackColor = True
        '
        'rdoRetro
        '
        Me.rdoRetro.AutoSize = True
        Me.rdoRetro.Location = New System.Drawing.Point(21, 65)
        Me.rdoRetro.Margin = New System.Windows.Forms.Padding(4)
        Me.rdoRetro.Name = "rdoRetro"
        Me.rdoRetro.Size = New System.Drawing.Size(124, 22)
        Me.rdoRetro.TabIndex = 1
        Me.rdoRetro.TabStop = True
        Me.rdoRetro.Text = "Retro (€49.50)"
        Me.rdoRetro.UseVisualStyleBackColor = True
        '
        'rdoVintage
        '
        Me.rdoVintage.AutoSize = True
        Me.rdoVintage.Location = New System.Drawing.Point(21, 95)
        Me.rdoVintage.Margin = New System.Windows.Forms.Padding(4)
        Me.rdoVintage.Name = "rdoVintage"
        Me.rdoVintage.Size = New System.Drawing.Size(135, 22)
        Me.rdoVintage.TabIndex = 2
        Me.rdoVintage.TabStop = True
        Me.rdoVintage.Text = "Vintage (€44.99)"
        Me.rdoVintage.UseVisualStyleBackColor = True
        '
        'cmbHeel
        '
        Me.cmbHeel.FormattingEnabled = True
        Me.cmbHeel.Items.AddRange(New Object() {"White", "Red", "Blue", "Green", "Yellow", "Dark Grey", "Light Grey", "Black"})
        Me.cmbHeel.Location = New System.Drawing.Point(127, 228)
        Me.cmbHeel.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbHeel.Name = "cmbHeel"
        Me.cmbHeel.Size = New System.Drawing.Size(180, 26)
        Me.cmbHeel.TabIndex = 20
        Me.cmbHeel.Text = "White"
        '
        'lblHeel
        '
        Me.lblHeel.AutoSize = True
        Me.lblHeel.Location = New System.Drawing.Point(52, 228)
        Me.lblHeel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblHeel.Name = "lblHeel"
        Me.lblHeel.Size = New System.Drawing.Size(42, 18)
        Me.lblHeel.TabIndex = 19
        Me.lblHeel.Text = "Heel:"
        '
        'cmbEyestay
        '
        Me.cmbEyestay.FormattingEnabled = True
        Me.cmbEyestay.Items.AddRange(New Object() {"White", "Red", "Blue", "Green", "Yellow", "Dark Grey", "Light Grey", "Black"})
        Me.cmbEyestay.Location = New System.Drawing.Point(127, 129)
        Me.cmbEyestay.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbEyestay.Name = "cmbEyestay"
        Me.cmbEyestay.Size = New System.Drawing.Size(180, 26)
        Me.cmbEyestay.TabIndex = 18
        Me.cmbEyestay.Text = "White"
        '
        'lblEyestay
        '
        Me.lblEyestay.AutoSize = True
        Me.lblEyestay.Location = New System.Drawing.Point(28, 134)
        Me.lblEyestay.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblEyestay.Name = "lblEyestay"
        Me.lblEyestay.Size = New System.Drawing.Size(64, 18)
        Me.lblEyestay.TabIndex = 17
        Me.lblEyestay.Text = "Eyestay:"
        '
        'cmbVamp
        '
        Me.cmbVamp.FormattingEnabled = True
        Me.cmbVamp.Items.AddRange(New Object() {"White", "Red ", "Blue", "Green", "Yellow", "Dark Grey", "Light Grey", "Black"})
        Me.cmbVamp.Location = New System.Drawing.Point(127, 80)
        Me.cmbVamp.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbVamp.Name = "cmbVamp"
        Me.cmbVamp.Size = New System.Drawing.Size(180, 26)
        Me.cmbVamp.TabIndex = 15
        Me.cmbVamp.Text = "White"
        '
        'lblVamp
        '
        Me.lblVamp.AutoSize = True
        Me.lblVamp.Location = New System.Drawing.Point(44, 86)
        Me.lblVamp.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblVamp.Name = "lblVamp"
        Me.lblVamp.Size = New System.Drawing.Size(50, 18)
        Me.lblVamp.TabIndex = 14
        Me.lblVamp.Text = "Vamp:"
        '
        'lblQuarter
        '
        Me.lblQuarter.AutoSize = True
        Me.lblQuarter.Location = New System.Drawing.Point(29, 29)
        Me.lblQuarter.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblQuarter.Name = "lblQuarter"
        Me.lblQuarter.Size = New System.Drawing.Size(62, 18)
        Me.lblQuarter.TabIndex = 13
        Me.lblQuarter.Text = "Quarter:"
        '
        'cmbQuarter
        '
        Me.cmbQuarter.FormattingEnabled = True
        Me.cmbQuarter.Items.AddRange(New Object() {"White ", "Red", "Blue", "Green", "Yellow", "Dark Grey", "Light Grey", "Black"})
        Me.cmbQuarter.Location = New System.Drawing.Point(127, 26)
        Me.cmbQuarter.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbQuarter.Name = "cmbQuarter"
        Me.cmbQuarter.Size = New System.Drawing.Size(180, 26)
        Me.cmbQuarter.TabIndex = 12
        Me.cmbQuarter.Text = "White "
        '
        'grpSModel
        '
        Me.grpSModel.Controls.Add(Me.cmbSize)
        Me.grpSModel.Controls.Add(Me.lblSize)
        Me.grpSModel.Controls.Add(Me.rdoVintage)
        Me.grpSModel.Controls.Add(Me.rdoRetro)
        Me.grpSModel.Controls.Add(Me.rdoClassic)
        Me.grpSModel.Location = New System.Drawing.Point(46, 27)
        Me.grpSModel.Name = "grpSModel"
        Me.grpSModel.Size = New System.Drawing.Size(321, 209)
        Me.grpSModel.TabIndex = 22
        Me.grpSModel.TabStop = False
        Me.grpSModel.Text = "Shoe Model and Size"
        '
        'cmbSize
        '
        Me.cmbSize.FormattingEnabled = True
        Me.cmbSize.Items.AddRange(New Object() {"UK 3", "UK 4", "UK 5", "UK 6", "UK 7", "UK 8", "UK 9", "UK 10", "UK 11", "UK 12"})
        Me.cmbSize.Location = New System.Drawing.Point(85, 141)
        Me.cmbSize.Name = "cmbSize"
        Me.cmbSize.Size = New System.Drawing.Size(99, 26)
        Me.cmbSize.TabIndex = 4
        '
        'lblSize
        '
        Me.lblSize.AutoSize = True
        Me.lblSize.Location = New System.Drawing.Point(32, 144)
        Me.lblSize.Name = "lblSize"
        Me.lblSize.Size = New System.Drawing.Size(41, 18)
        Me.lblSize.TabIndex = 3
        Me.lblSize.Text = "Size:"
        '
        'grpColour
        '
        Me.grpColour.Controls.Add(Me.cmbLaces)
        Me.grpColour.Controls.Add(Me.lblLaces)
        Me.grpColour.Controls.Add(Me.cmbHeelback)
        Me.grpColour.Controls.Add(Me.lblHeelback)
        Me.grpColour.Controls.Add(Me.cmbHeel)
        Me.grpColour.Controls.Add(Me.lblHeel)
        Me.grpColour.Controls.Add(Me.cmbEyestay)
        Me.grpColour.Controls.Add(Me.lblEyestay)
        Me.grpColour.Controls.Add(Me.cmbVamp)
        Me.grpColour.Controls.Add(Me.lblVamp)
        Me.grpColour.Controls.Add(Me.lblQuarter)
        Me.grpColour.Controls.Add(Me.cmbQuarter)
        Me.grpColour.Location = New System.Drawing.Point(46, 255)
        Me.grpColour.Name = "grpColour"
        Me.grpColour.Size = New System.Drawing.Size(321, 339)
        Me.grpColour.TabIndex = 23
        Me.grpColour.TabStop = False
        Me.grpColour.Text = "Colour Options"
        '
        'cmbLaces
        '
        Me.cmbLaces.FormattingEnabled = True
        Me.cmbLaces.Items.AddRange(New Object() {"White", "Red", "Blue", "Green", "Yellow", "Dark Grey", "Light Grey", "Black"})
        Me.cmbLaces.Location = New System.Drawing.Point(127, 184)
        Me.cmbLaces.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbLaces.Name = "cmbLaces"
        Me.cmbLaces.Size = New System.Drawing.Size(180, 26)
        Me.cmbLaces.TabIndex = 24
        Me.cmbLaces.Text = "White"
        '
        'lblLaces
        '
        Me.lblLaces.AutoSize = True
        Me.lblLaces.Location = New System.Drawing.Point(42, 184)
        Me.lblLaces.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblLaces.Name = "lblLaces"
        Me.lblLaces.Size = New System.Drawing.Size(52, 18)
        Me.lblLaces.TabIndex = 23
        Me.lblLaces.Text = "Laces:"
        '
        'cmbHeelback
        '
        Me.cmbHeelback.FormattingEnabled = True
        Me.cmbHeelback.Items.AddRange(New Object() {"White", "Red", "Blue", "Yellow", "Dark Grey", "Light Grey", "Black"})
        Me.cmbHeelback.Location = New System.Drawing.Point(127, 278)
        Me.cmbHeelback.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbHeelback.Name = "cmbHeelback"
        Me.cmbHeelback.Size = New System.Drawing.Size(180, 26)
        Me.cmbHeelback.TabIndex = 22
        Me.cmbHeelback.Text = "White"
        '
        'lblHeelback
        '
        Me.lblHeelback.AutoSize = True
        Me.lblHeelback.Location = New System.Drawing.Point(18, 281)
        Me.lblHeelback.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblHeelback.Name = "lblHeelback"
        Me.lblHeelback.Size = New System.Drawing.Size(74, 18)
        Me.lblHeelback.TabIndex = 21
        Me.lblHeelback.Text = "Heelback:"
        '
        'lblFileSelected
        '
        Me.lblFileSelected.AutoSize = True
        Me.lblFileSelected.Location = New System.Drawing.Point(36, 188)
        Me.lblFileSelected.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblFileSelected.Name = "lblFileSelected"
        Me.lblFileSelected.Size = New System.Drawing.Size(109, 18)
        Me.lblFileSelected.TabIndex = 27
        Me.lblFileSelected.Text = "No file selected"
        '
        'btnLogo
        '
        Me.btnLogo.Location = New System.Drawing.Point(269, 108)
        Me.btnLogo.Margin = New System.Windows.Forms.Padding(4)
        Me.btnLogo.Name = "btnLogo"
        Me.btnLogo.Size = New System.Drawing.Size(112, 32)
        Me.btnLogo.TabIndex = 26
        Me.btnLogo.Text = "Browse Files"
        Me.btnLogo.UseVisualStyleBackColor = True
        '
        'lblLogo
        '
        Me.lblLogo.AutoSize = True
        Me.lblLogo.Location = New System.Drawing.Point(36, 108)
        Me.lblLogo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblLogo.Name = "lblLogo"
        Me.lblLogo.Size = New System.Drawing.Size(145, 18)
        Me.lblLogo.TabIndex = 25
        Me.lblLogo.Text = "Add Your Own Logo:"
        '
        'grpLogo
        '
        Me.grpLogo.Controls.Add(Me.pctLogo)
        Me.grpLogo.Controls.Add(Me.grpLogo2)
        Me.grpLogo.Controls.Add(Me.lblLogo)
        Me.grpLogo.Controls.Add(Me.lblFileSelected)
        Me.grpLogo.Controls.Add(Me.btnLogo)
        Me.grpLogo.Location = New System.Drawing.Point(387, 27)
        Me.grpLogo.Name = "grpLogo"
        Me.grpLogo.Size = New System.Drawing.Size(397, 567)
        Me.grpLogo.TabIndex = 28
        Me.grpLogo.TabStop = False
        Me.grpLogo.Text = "Logo"
        '
        'pctLogo
        '
        Me.pctLogo.Location = New System.Drawing.Point(46, 267)
        Me.pctLogo.Name = "pctLogo"
        Me.pctLogo.Size = New System.Drawing.Size(304, 266)
        Me.pctLogo.TabIndex = 30
        Me.pctLogo.TabStop = False
        '
        'grpLogo2
        '
        Me.grpLogo2.Controls.Add(Me.rdoNoLogo)
        Me.grpLogo2.Controls.Add(Me.rdoYesLogo)
        Me.grpLogo2.Location = New System.Drawing.Point(25, 35)
        Me.grpLogo2.Name = "grpLogo2"
        Me.grpLogo2.Size = New System.Drawing.Size(226, 70)
        Me.grpLogo2.TabIndex = 29
        Me.grpLogo2.TabStop = False
        Me.grpLogo2.Text = "Do you want to add a Logo?"
        '
        'rdoNoLogo
        '
        Me.rdoNoLogo.AutoSize = True
        Me.rdoNoLogo.Location = New System.Drawing.Point(125, 24)
        Me.rdoNoLogo.Name = "rdoNoLogo"
        Me.rdoNoLogo.Size = New System.Drawing.Size(49, 22)
        Me.rdoNoLogo.TabIndex = 29
        Me.rdoNoLogo.TabStop = True
        Me.rdoNoLogo.Text = "No"
        Me.rdoNoLogo.UseVisualStyleBackColor = True
        '
        'rdoYesLogo
        '
        Me.rdoYesLogo.AutoSize = True
        Me.rdoYesLogo.Location = New System.Drawing.Point(25, 24)
        Me.rdoYesLogo.Name = "rdoYesLogo"
        Me.rdoYesLogo.Size = New System.Drawing.Size(54, 22)
        Me.rdoYesLogo.TabIndex = 28
        Me.rdoYesLogo.TabStop = True
        Me.rdoYesLogo.Text = "Yes"
        Me.rdoYesLogo.UseVisualStyleBackColor = True
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(684, 639)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(84, 39)
        Me.btnCalculate.TabIndex = 29
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'grpText
        '
        Me.grpText.Controls.Add(Me.trkSize)
        Me.grpText.Controls.Add(Me.lblFontStyle)
        Me.grpText.Controls.Add(Me.lblFont)
        Me.grpText.Controls.Add(Me.cmbFontStyle)
        Me.grpText.Controls.Add(Me.cmbFont)
        Me.grpText.Controls.Add(Me.rchText)
        Me.grpText.Controls.Add(Me.rdoNoText)
        Me.grpText.Controls.Add(Me.rdoYesText)
        Me.grpText.Location = New System.Drawing.Point(807, 27)
        Me.grpText.Name = "grpText"
        Me.grpText.Size = New System.Drawing.Size(501, 555)
        Me.grpText.TabIndex = 30
        Me.grpText.TabStop = False
        Me.grpText.Text = "Add Text?"
        '
        'trkSize
        '
        Me.trkSize.Location = New System.Drawing.Point(30, 192)
        Me.trkSize.Name = "trkSize"
        Me.trkSize.Size = New System.Drawing.Size(464, 56)
        Me.trkSize.TabIndex = 7
        '
        'lblFontStyle
        '
        Me.lblFontStyle.AutoSize = True
        Me.lblFontStyle.Location = New System.Drawing.Point(81, 151)
        Me.lblFontStyle.Name = "lblFontStyle"
        Me.lblFontStyle.Size = New System.Drawing.Size(78, 18)
        Me.lblFontStyle.TabIndex = 6
        Me.lblFontStyle.Text = "Font Style:"
        '
        'lblFont
        '
        Me.lblFont.AutoSize = True
        Me.lblFont.Location = New System.Drawing.Point(120, 98)
        Me.lblFont.Name = "lblFont"
        Me.lblFont.Size = New System.Drawing.Size(42, 18)
        Me.lblFont.TabIndex = 5
        Me.lblFont.Text = "Font:"
        '
        'cmbFontStyle
        '
        Me.cmbFontStyle.FormattingEnabled = True
        Me.cmbFontStyle.Location = New System.Drawing.Point(183, 147)
        Me.cmbFontStyle.Name = "cmbFontStyle"
        Me.cmbFontStyle.Size = New System.Drawing.Size(136, 26)
        Me.cmbFontStyle.TabIndex = 4
        '
        'cmbFont
        '
        Me.cmbFont.FormattingEnabled = True
        Me.cmbFont.Location = New System.Drawing.Point(183, 98)
        Me.cmbFont.Name = "cmbFont"
        Me.cmbFont.Size = New System.Drawing.Size(136, 26)
        Me.cmbFont.TabIndex = 3
        '
        'rchText
        '
        Me.rchText.Location = New System.Drawing.Point(19, 262)
        Me.rchText.Name = "rchText"
        Me.rchText.Size = New System.Drawing.Size(474, 270)
        Me.rchText.TabIndex = 2
        Me.rchText.Text = ""
        '
        'rdoNoText
        '
        Me.rdoNoText.AutoSize = True
        Me.rdoNoText.Location = New System.Drawing.Point(270, 47)
        Me.rdoNoText.Name = "rdoNoText"
        Me.rdoNoText.Size = New System.Drawing.Size(49, 22)
        Me.rdoNoText.TabIndex = 1
        Me.rdoNoText.TabStop = True
        Me.rdoNoText.Text = "No"
        Me.rdoNoText.UseVisualStyleBackColor = True
        '
        'rdoYesText
        '
        Me.rdoYesText.AutoSize = True
        Me.rdoYesText.Location = New System.Drawing.Point(61, 47)
        Me.rdoYesText.Name = "rdoYesText"
        Me.rdoYesText.Size = New System.Drawing.Size(54, 22)
        Me.rdoYesText.TabIndex = 0
        Me.rdoYesText.TabStop = True
        Me.rdoYesText.Text = "Yes"
        Me.rdoYesText.UseVisualStyleBackColor = True
        '
        'txtSubtotal
        '
        Me.txtSubtotal.Location = New System.Drawing.Point(506, 648)
        Me.txtSubtotal.Name = "txtSubtotal"
        Me.txtSubtotal.Size = New System.Drawing.Size(143, 24)
        Me.txtSubtotal.TabIndex = 31
        '
        'lblSubTotal
        '
        Me.lblSubTotal.AutoSize = True
        Me.lblSubTotal.Location = New System.Drawing.Point(425, 651)
        Me.lblSubTotal.Name = "lblSubTotal"
        Me.lblSubTotal.Size = New System.Drawing.Size(75, 18)
        Me.lblSubTotal.TabIndex = 32
        Me.lblSubTotal.Text = "Sub Total:"
        '
        'btnProceed
        '
        Me.btnProceed.Location = New System.Drawing.Point(1019, 641)
        Me.btnProceed.Name = "btnProceed"
        Me.btnProceed.Size = New System.Drawing.Size(199, 39)
        Me.btnProceed.TabIndex = 33
        Me.btnProceed.Text = "Proceed to Payment"
        Me.btnProceed.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(684, 699)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(84, 37)
        Me.btnCancel.TabIndex = 34
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnHome
        '
        Me.btnHome.Location = New System.Drawing.Point(46, 638)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(73, 31)
        Me.btnHome.TabIndex = 35
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'frmYourStyle
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(1321, 748)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnProceed)
        Me.Controls.Add(Me.lblSubTotal)
        Me.Controls.Add(Me.txtSubtotal)
        Me.Controls.Add(Me.grpText)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.grpColour)
        Me.Controls.Add(Me.grpLogo)
        Me.Controls.Add(Me.grpSModel)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.ImeMode = System.Windows.Forms.ImeMode.[On]
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmYourStyle"
        Me.Text = "Home"
        Me.grpSModel.ResumeLayout(False)
        Me.grpSModel.PerformLayout()
        Me.grpColour.ResumeLayout(False)
        Me.grpColour.PerformLayout()
        Me.grpLogo.ResumeLayout(False)
        Me.grpLogo.PerformLayout()
        CType(Me.pctLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpLogo2.ResumeLayout(False)
        Me.grpLogo2.PerformLayout()
        Me.grpText.ResumeLayout(False)
        Me.grpText.PerformLayout()
        CType(Me.trkSize, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents rdoClassic As RadioButton
    Friend WithEvents rdoRetro As RadioButton
    Friend WithEvents rdoVintage As RadioButton
    Friend WithEvents cmbHeel As ComboBox
    Friend WithEvents lblHeel As Label
    Friend WithEvents cmbEyestay As ComboBox
    Friend WithEvents lblEyestay As Label
    Friend WithEvents cmbVamp As ComboBox
    Friend WithEvents lblVamp As Label
    Friend WithEvents lblQuarter As Label
    Friend WithEvents cmbQuarter As ComboBox
    Friend WithEvents grpSModel As GroupBox
    Friend WithEvents grpColour As GroupBox
    Friend WithEvents cmbLaces As ComboBox
    Friend WithEvents lblLaces As Label
    Friend WithEvents cmbHeelback As ComboBox
    Friend WithEvents lblHeelback As Label
    Friend WithEvents lblFileSelected As Label
    Friend WithEvents btnLogo As Button
    Friend WithEvents lblLogo As Label
    Friend WithEvents grpLogo As GroupBox
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents btnCalculate As Button
    Friend WithEvents grpLogo2 As GroupBox
    Friend WithEvents rdoYesLogo As RadioButton
    Friend WithEvents rdoNoLogo As RadioButton
    Friend WithEvents pctLogo As PictureBox
    Friend WithEvents grpText As GroupBox
    Friend WithEvents rdoNoText As RadioButton
    Friend WithEvents rdoYesText As RadioButton
    Friend WithEvents rchText As RichTextBox
    Friend WithEvents trkSize As TrackBar
    Friend WithEvents lblFontStyle As Label
    Friend WithEvents lblFont As Label
    Friend WithEvents cmbFontStyle As ComboBox
    Friend WithEvents cmbFont As ComboBox
    Friend WithEvents txtSubtotal As TextBox
    Friend WithEvents lblSubTotal As Label
    Friend WithEvents btnProceed As Button
    Friend WithEvents btnCancel As Button
    Friend WithEvents btnHome As Button
    Friend WithEvents cmbSize As ComboBox
    Friend WithEvents lblSize As Label
End Class
