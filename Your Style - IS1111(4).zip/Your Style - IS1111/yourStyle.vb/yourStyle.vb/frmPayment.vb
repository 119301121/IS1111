﻿Public Class frmPayment
    Private Sub btnEditStyle_Click(sender As Object, e As EventArgs) Handles btnEditStyle.Click
        lstBreakdown.Items.Clear()
        Me.Hide()
        frmYourStyle.Show()
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        lstBreakdown.Items.Clear()
        Me.Hide()
        frmHome.Show()
    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        lstBreakdown.ClearSelected()
        Me.Hide()
        frmHome.Show()

    End Sub

    Private Sub btnFinishPay_Click(sender As Object, e As EventArgs) Handles btnFinishPay.Click
        'final receipt displayed in the same listbox as the breakdown of prices
        lstBreakdown.Items.Clear()
        lstBreakdown.Items.Add("        Customer Receipt")
        lstBreakdown.Items.Add("")
        lstBreakdown.Items.Add("")
        lstBreakdown.Items.Add("Customer Info")
        lstBreakdown.Items.Add("Name: " & txtCName.Text)
        lstBreakdown.Items.Add("Contact Number: " & mskContactNo.Text)
        lstBreakdown.Items.Add("Email: " & txtEmail.Text)
        lstBreakdown.Items.Add("Delvery Address: " & rchAddress.Text)
        lstBreakdown.Items.Add("Payment Type: " & cmbPayType.Text)
        lstBreakdown.Items.Add("")
        lstBreakdown.Items.Add("        Order Details")
        lstBreakdown.Items.Add("")
        lstBreakdown.Items.Add("Shoe Size: " & frmYourStyle.cmbSize.Text)
        lstBreakdown.Items.Add("Quarter Colour: " & frmYourStyle.cmbQuarter.Text & "@ " & "€" & dblQuarter)
        lstBreakdown.Items.Add("Vamp Colour: " & frmYourStyle.cmbVamp.Text & "@ " & "€" & dblVamp)
        lstBreakdown.Items.Add("Eyestay Colour: " & frmYourStyle.cmbEyestay.Text & "@ " & "€" & dblEyestay)
        lstBreakdown.Items.Add("Heel Colour: " & frmYourStyle.cmbHeel.Text & "@ " & "€" & dblHeel)
        lstBreakdown.Items.Add("Heelback Colour: " & frmYourStyle.cmbHeelback.Text & "@ " & "€" & dblHeelBack)
        lstBreakdown.Items.Add("Laces Colour: " & frmYourStyle.cmbLaces.Text & "@ " & "€" & dblLaces)
        lstBreakdown.Items.Add("Logo: " & "€" & dblLogo)
        lstBreakdown.Items.Add("Text: " & "€" & dblText)
        lstBreakdown.Items.Add("Subtotal: " & "€" & dblSubTotal & " per shoe")
        lstBreakdown.Items.Add("V.A.T. @ 23% = " & dblVat)
        lstBreakdown.Items.Add("Total Paid: " & "€" & dblTotal)
        lstBreakdown.Items.Add("")
        lstBreakdown.Items.Add("")
        lstBreakdown.Items.Add("        Thank You!")







    End Sub

    Private Sub frmPayment_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class