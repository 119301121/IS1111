﻿Public Class frmHome
    'Breakdown of Responsibilities
    'Alastair Kavanagh -> Calculations for customisation form, building manager form and table for database
    'Nicole Herana -> Building database (customisation table, customer information table, customer login info table)
    'helped fix calculations, built payment form and homepage
    'Kevin Quirke -> Customer login, building manager form
    'Caroline Nolan -> User manual (word document format)
    Private Sub btnOpenCustomer_Click(sender As Object, e As EventArgs) Handles btnOpenCustomer.Click

    End Sub

    Private Sub btnOpenManager_Click(sender As Object, e As EventArgs) Handles btnOpenManager.Click

    End Sub

End Class