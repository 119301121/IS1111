﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmHome
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmHome))
        Me.grpHome = New System.Windows.Forms.GroupBox()
        Me.btnOpenManager = New System.Windows.Forms.Button()
        Me.btnOpenEmployee = New System.Windows.Forms.Button()
        Me.btnOpenCustomer = New System.Windows.Forms.Button()
        Me.grpHome.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpHome
        '
        Me.grpHome.BackColor = System.Drawing.Color.Transparent
        Me.grpHome.Controls.Add(Me.btnOpenManager)
        Me.grpHome.Controls.Add(Me.btnOpenEmployee)
        Me.grpHome.Controls.Add(Me.btnOpenCustomer)
        Me.grpHome.Font = New System.Drawing.Font("Mongolian Baiti", 13.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpHome.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.grpHome.Location = New System.Drawing.Point(92, 133)
        Me.grpHome.Name = "grpHome"
        Me.grpHome.Size = New System.Drawing.Size(394, 320)
        Me.grpHome.TabIndex = 1
        Me.grpHome.TabStop = False
        Me.grpHome.Text = "Welcome - Please Click User"
        '
        'btnOpenManager
        '
        Me.btnOpenManager.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.btnOpenManager.Location = New System.Drawing.Point(116, 177)
        Me.btnOpenManager.Name = "btnOpenManager"
        Me.btnOpenManager.Size = New System.Drawing.Size(176, 39)
        Me.btnOpenManager.TabIndex = 2
        Me.btnOpenManager.Text = "Manager"
        Me.btnOpenManager.UseVisualStyleBackColor = True
        '
        'btnOpenEmployee
        '
        Me.btnOpenEmployee.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.btnOpenEmployee.Location = New System.Drawing.Point(116, 123)
        Me.btnOpenEmployee.Name = "btnOpenEmployee"
        Me.btnOpenEmployee.Size = New System.Drawing.Size(176, 39)
        Me.btnOpenEmployee.TabIndex = 1
        Me.btnOpenEmployee.Text = "Employee"
        Me.btnOpenEmployee.UseVisualStyleBackColor = True
        '
        'btnOpenCustomer
        '
        Me.btnOpenCustomer.BackColor = System.Drawing.Color.Transparent
        Me.btnOpenCustomer.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.btnOpenCustomer.Location = New System.Drawing.Point(116, 68)
        Me.btnOpenCustomer.Name = "btnOpenCustomer"
        Me.btnOpenCustomer.Size = New System.Drawing.Size(176, 39)
        Me.btnOpenCustomer.TabIndex = 0
        Me.btnOpenCustomer.Text = "Customer"
        Me.btnOpenCustomer.UseVisualStyleBackColor = False
        '
        'frmHome
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(591, 592)
        Me.Controls.Add(Me.grpHome)
        Me.Name = "frmHome"
        Me.Text = "Your Style - Home"
        Me.grpHome.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grpHome As GroupBox
    Friend WithEvents btnOpenManager As Button
    Friend WithEvents btnOpenEmployee As Button
    Friend WithEvents btnOpenCustomer As Button
End Class
