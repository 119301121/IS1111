﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPayment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPayment))
        Me.btnHome = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnEditStyle = New System.Windows.Forms.Button()
        Me.grpCustomerDetails = New System.Windows.Forms.GroupBox()
        Me.mskContactNo = New System.Windows.Forms.MaskedTextBox()
        Me.mskCVV = New System.Windows.Forms.MaskedTextBox()
        Me.mskExpiry = New System.Windows.Forms.MaskedTextBox()
        Me.lblCVV = New System.Windows.Forms.Label()
        Me.btnFinishPay = New System.Windows.Forms.Button()
        Me.lblExpiry = New System.Windows.Forms.Label()
        Me.mskCardNo = New System.Windows.Forms.MaskedTextBox()
        Me.cmbPayType = New System.Windows.Forms.ComboBox()
        Me.rchAddress = New System.Windows.Forms.RichTextBox()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.txtCName = New System.Windows.Forms.TextBox()
        Me.lblCardNo = New System.Windows.Forms.Label()
        Me.lblPayType = New System.Windows.Forms.Label()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.lblEmail = New System.Windows.Forms.Label()
        Me.lblContactNo = New System.Windows.Forms.Label()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lstBreakdown = New System.Windows.Forms.ListBox()
        Me.grpCustomerDetails.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnHome
        '
        Me.btnHome.Location = New System.Drawing.Point(98, 578)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(115, 35)
        Me.btnHome.TabIndex = 10
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(297, 578)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(132, 35)
        Me.btnCancel.TabIndex = 9
        Me.btnCancel.Text = "Cancel Order"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnEditStyle
        '
        Me.btnEditStyle.Location = New System.Drawing.Point(98, 537)
        Me.btnEditStyle.Name = "btnEditStyle"
        Me.btnEditStyle.Size = New System.Drawing.Size(115, 35)
        Me.btnEditStyle.TabIndex = 8
        Me.btnEditStyle.Text = "Edit"
        Me.btnEditStyle.UseVisualStyleBackColor = True
        '
        'grpCustomerDetails
        '
        Me.grpCustomerDetails.Controls.Add(Me.mskContactNo)
        Me.grpCustomerDetails.Controls.Add(Me.mskCVV)
        Me.grpCustomerDetails.Controls.Add(Me.mskExpiry)
        Me.grpCustomerDetails.Controls.Add(Me.lblCVV)
        Me.grpCustomerDetails.Controls.Add(Me.btnFinishPay)
        Me.grpCustomerDetails.Controls.Add(Me.lblExpiry)
        Me.grpCustomerDetails.Controls.Add(Me.mskCardNo)
        Me.grpCustomerDetails.Controls.Add(Me.cmbPayType)
        Me.grpCustomerDetails.Controls.Add(Me.rchAddress)
        Me.grpCustomerDetails.Controls.Add(Me.txtEmail)
        Me.grpCustomerDetails.Controls.Add(Me.txtCName)
        Me.grpCustomerDetails.Controls.Add(Me.lblCardNo)
        Me.grpCustomerDetails.Controls.Add(Me.lblPayType)
        Me.grpCustomerDetails.Controls.Add(Me.lblAddress)
        Me.grpCustomerDetails.Controls.Add(Me.lblEmail)
        Me.grpCustomerDetails.Controls.Add(Me.lblContactNo)
        Me.grpCustomerDetails.Controls.Add(Me.lblName)
        Me.grpCustomerDetails.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold)
        Me.grpCustomerDetails.Location = New System.Drawing.Point(480, 45)
        Me.grpCustomerDetails.Name = "grpCustomerDetails"
        Me.grpCustomerDetails.Size = New System.Drawing.Size(559, 582)
        Me.grpCustomerDetails.TabIndex = 7
        Me.grpCustomerDetails.TabStop = False
        Me.grpCustomerDetails.Text = "Customer Details"
        '
        'mskContactNo
        '
        Me.mskContactNo.Location = New System.Drawing.Point(152, 72)
        Me.mskContactNo.Mask = "(999) 000-0000"
        Me.mskContactNo.Name = "mskContactNo"
        Me.mskContactNo.Size = New System.Drawing.Size(202, 24)
        Me.mskContactNo.TabIndex = 16
        '
        'mskCVV
        '
        Me.mskCVV.Location = New System.Drawing.Point(152, 400)
        Me.mskCVV.Mask = "000"
        Me.mskCVV.Name = "mskCVV"
        Me.mskCVV.Size = New System.Drawing.Size(48, 24)
        Me.mskCVV.TabIndex = 15
        '
        'mskExpiry
        '
        Me.mskExpiry.Location = New System.Drawing.Point(151, 368)
        Me.mskExpiry.Mask = "00/00"
        Me.mskExpiry.Name = "mskExpiry"
        Me.mskExpiry.Size = New System.Drawing.Size(61, 24)
        Me.mskExpiry.TabIndex = 14
        '
        'lblCVV
        '
        Me.lblCVV.AutoSize = True
        Me.lblCVV.Location = New System.Drawing.Point(100, 406)
        Me.lblCVV.Name = "lblCVV"
        Me.lblCVV.Size = New System.Drawing.Size(45, 18)
        Me.lblCVV.TabIndex = 13
        Me.lblCVV.Text = "CVV:"
        '
        'btnFinishPay
        '
        Me.btnFinishPay.Location = New System.Drawing.Point(345, 459)
        Me.btnFinishPay.Name = "btnFinishPay"
        Me.btnFinishPay.Size = New System.Drawing.Size(132, 35)
        Me.btnFinishPay.TabIndex = 2
        Me.btnFinishPay.Text = "Finish Payment"
        Me.btnFinishPay.UseVisualStyleBackColor = True
        '
        'lblExpiry
        '
        Me.lblExpiry.AutoSize = True
        Me.lblExpiry.Location = New System.Drawing.Point(86, 371)
        Me.lblExpiry.Name = "lblExpiry"
        Me.lblExpiry.Size = New System.Drawing.Size(59, 18)
        Me.lblExpiry.TabIndex = 12
        Me.lblExpiry.Text = "Expiry:"
        '
        'mskCardNo
        '
        Me.mskCardNo.Location = New System.Drawing.Point(151, 332)
        Me.mskCardNo.Mask = "0000-0000-0000-0000"
        Me.mskCardNo.Name = "mskCardNo"
        Me.mskCardNo.Size = New System.Drawing.Size(185, 24)
        Me.mskCardNo.TabIndex = 11
        '
        'cmbPayType
        '
        Me.cmbPayType.FormattingEnabled = True
        Me.cmbPayType.Items.AddRange(New Object() {"Mastercard", "Visa Debit", "Visa Credit", "PayPal"})
        Me.cmbPayType.Location = New System.Drawing.Point(151, 300)
        Me.cmbPayType.Name = "cmbPayType"
        Me.cmbPayType.Size = New System.Drawing.Size(203, 26)
        Me.cmbPayType.TabIndex = 10
        '
        'rchAddress
        '
        Me.rchAddress.Location = New System.Drawing.Point(151, 155)
        Me.rchAddress.Name = "rchAddress"
        Me.rchAddress.Size = New System.Drawing.Size(326, 136)
        Me.rchAddress.TabIndex = 9
        Me.rchAddress.Text = ""
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(151, 114)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(224, 24)
        Me.txtEmail.TabIndex = 8
        '
        'txtCName
        '
        Me.txtCName.Location = New System.Drawing.Point(151, 35)
        Me.txtCName.Name = "txtCName"
        Me.txtCName.Size = New System.Drawing.Size(286, 24)
        Me.txtCName.TabIndex = 6
        '
        'lblCardNo
        '
        Me.lblCardNo.AutoSize = True
        Me.lblCardNo.Location = New System.Drawing.Point(32, 338)
        Me.lblCardNo.Name = "lblCardNo"
        Me.lblCardNo.Size = New System.Drawing.Size(113, 18)
        Me.lblCardNo.TabIndex = 5
        Me.lblCardNo.Text = "Card Number:"
        '
        'lblPayType
        '
        Me.lblPayType.AutoSize = True
        Me.lblPayType.Location = New System.Drawing.Point(26, 303)
        Me.lblPayType.Name = "lblPayType"
        Me.lblPayType.Size = New System.Drawing.Size(119, 18)
        Me.lblPayType.TabIndex = 4
        Me.lblPayType.Text = "Payment Type:"
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.Location = New System.Drawing.Point(10, 153)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(139, 18)
        Me.lblAddress.TabIndex = 3
        Me.lblAddress.Text = "Delivery Address:"
        '
        'lblEmail
        '
        Me.lblEmail.AutoSize = True
        Me.lblEmail.Location = New System.Drawing.Point(90, 117)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(55, 18)
        Me.lblEmail.TabIndex = 2
        Me.lblEmail.Text = "Email:"
        '
        'lblContactNo
        '
        Me.lblContactNo.AutoSize = True
        Me.lblContactNo.Location = New System.Drawing.Point(9, 75)
        Me.lblContactNo.Name = "lblContactNo"
        Me.lblContactNo.Size = New System.Drawing.Size(136, 18)
        Me.lblContactNo.TabIndex = 1
        Me.lblContactNo.Text = "Contact Number:"
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Location = New System.Drawing.Point(56, 41)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(89, 18)
        Me.lblName.TabIndex = 0
        Me.lblName.Text = "Full Name:"
        '
        'lstBreakdown
        '
        Me.lstBreakdown.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstBreakdown.FormattingEnabled = True
        Me.lstBreakdown.ItemHeight = 21
        Me.lstBreakdown.Location = New System.Drawing.Point(60, 40)
        Me.lstBreakdown.Name = "lstBreakdown"
        Me.lstBreakdown.Size = New System.Drawing.Size(387, 487)
        Me.lstBreakdown.TabIndex = 6
        '
        'frmPayment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1098, 666)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnEditStyle)
        Me.Controls.Add(Me.grpCustomerDetails)
        Me.Controls.Add(Me.lstBreakdown)
        Me.Name = "frmPayment"
        Me.Text = "Your Style - Payment"
        Me.grpCustomerDetails.ResumeLayout(False)
        Me.grpCustomerDetails.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnHome As Button
    Friend WithEvents btnCancel As Button
    Friend WithEvents btnEditStyle As Button
    Friend WithEvents grpCustomerDetails As GroupBox
    Friend WithEvents mskContactNo As MaskedTextBox
    Friend WithEvents mskCVV As MaskedTextBox
    Friend WithEvents mskExpiry As MaskedTextBox
    Friend WithEvents lblCVV As Label
    Friend WithEvents btnFinishPay As Button
    Friend WithEvents lblExpiry As Label
    Friend WithEvents mskCardNo As MaskedTextBox
    Friend WithEvents cmbPayType As ComboBox
    Friend WithEvents rchAddress As RichTextBox
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents txtCName As TextBox
    Friend WithEvents lblCardNo As Label
    Friend WithEvents lblPayType As Label
    Friend WithEvents lblAddress As Label
    Friend WithEvents lblEmail As Label
    Friend WithEvents lblContactNo As Label
    Friend WithEvents lblName As Label
    Friend WithEvents lstBreakdown As ListBox
End Class
