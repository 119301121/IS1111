﻿Module Variables
    'declaring variables for shoe prices etc. 
    Public strClassic As String
    Public strRetro As String
    Public strVintage As String

    Public strQuarter As String
    Public strVamp As String
    Public strEyestay As String
    Public strLaces As String
    Public strHeel As String
    Public strHeelback As String


    Public dblModel As Double
    Public dblCustomisation As Double

    Public dblClassic As Double = 54.99
    Public dblRetro As Double = 49.5
    Public dblVintage As Double = 44.99


    Public dblQuarter As Double
    Public dblVamp As Double
    Public dblEyestay As Double
    Public dblHeel As Double
    Public dblHeelBack As Double
    Public dblLaces As Double
    Public dblLogo As Double
    Public dblText As Double


    Public dblSubTotal As Double
    Public dblAddChar As Double = 0.05
    Public dblVat As Double
    Public dblTotal As Double


End Module