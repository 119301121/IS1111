﻿Module Variables
    'delcaring variables for shoe prices etc. 
    Public dblClassic As Double = 54.49
    Public dblRetro As Double = 49.5
    Public dblVintage As Double = 44.99
    Public dblQuarter As Double = 8.99
    Public dblVamp As Double = 14.99
    Public dblEyestay As Double = 5
    Public dblHeel As Double = 4.99
    Public dblHeelBack As Double = 6.49
    Public dblLaces As Double = 4
    Public dblLogo As Double = 0.18
    Public dblText As Double = 0.45
    Public dblAddChar As Double = 0.05
    Public dblVat As Double = 0.23

    'declaring a variable to hold the current price of the shoe 
    Public dblCurrentPrice As Double

End Module
