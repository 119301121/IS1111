﻿Public Class FrmCustomer
    'video i used https://www.youtube.com/watch?v=95ZE9gmaYEU&t=289s

    'i didnt know if the manager should be able to edit records or not so i just left it with a print option 
    Private Sub FrmCustomer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'YourStyleDataSet.Order_Summary' table. You can move, or remove it, as needed.
        Me.Order_SummaryTableAdapter.Fill(Me.YourStyleDataSet.Order_Summary)
        'TODO: This line of code loads data into the 'YourStyleDataSet.Customisation' table. You can move, or remove it, as needed.
        Me.CustomisationTableAdapter.Fill(Me.YourStyleDataSet.Customisation)
        'TODO: This line of code loads data into the 'YourStyleDataSet.Customer_Information' table. You can move, or remove it, as needed.
        Me.Customer_InformationTableAdapter.Fill(Me.YourStyleDataSet.Customer_Information)

        PrintPreviewControl1.Document = PrintDocument1
    End Sub

    Private Sub pctPrinter_Click(sender As Object, e As EventArgs) Handles pctPrinter.Click
        'goes to a mario meme i used before i figured out how to use the printer
        FrmPrintPreview.Show()
    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim ReportFont As Font = New Drawing.Font("Times New Roman", 14)
        'sets font and font colour and size, and what comes up on the print sheet
        'i didnt know how to get the database to print onto the sheet 
        e.Graphics.DrawString("I love VB", ReportFont, Brushes.Black, 100, 100)
        e.Graphics.DrawString("I can't figure out how to print the database", ReportFont, Brushes.Black, 100, 100)
    End Sub

    Private Sub btnPrevious_Click(sender As Object, e As EventArgs) Handles btnPrevious.Click
        FrmManager.Show()
        Me.Hide()
    End Sub
End Class