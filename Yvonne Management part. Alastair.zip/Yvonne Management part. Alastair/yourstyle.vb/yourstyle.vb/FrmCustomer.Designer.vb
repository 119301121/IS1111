﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmCustomer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmCustomer))
        Me.bndYourStyle = New System.Windows.Forms.BindingSource(Me.components)
        Me.YourStyleDataSet = New yourstyle.vb.YourStyleDataSet()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.CustomerIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CustomerNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AddressDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ContactNumberDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EmailDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OrderIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CustomerInformationBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Customer_InformationTableAdapter = New yourstyle.vb.YourStyleDataSetTableAdapters.Customer_InformationTableAdapter()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.OrderIDDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ModelDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.QuarterColourDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VampColourDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EyestayColourDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HeelTabColourDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HeelBackCounterColourDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LacesColourDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LogoDataGridViewCheckBoxColumn = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.Field1DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AddedTextDataGridViewCheckBoxColumn = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.EditedTextDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CustomisationBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CustomisationTableAdapter = New yourstyle.vb.YourStyleDataSetTableAdapters.CustomisationTableAdapter()
        Me.DataGridView3 = New System.Windows.Forms.DataGridView()
        Me.OrderIDDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ShoeModelDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LogoDataGridViewCheckBoxColumn1 = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.DateOrderedDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProvidedByCustomerDataGridViewCheckBoxColumn = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.SizeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StatusDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OrderSummaryBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Order_SummaryTableAdapter = New yourstyle.vb.YourStyleDataSetTableAdapters.Order_SummaryTableAdapter()
        Me.pctPrinter = New System.Windows.Forms.PictureBox()
        Me.btnPrevious = New System.Windows.Forms.Button()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.PrintPreviewControl1 = New System.Windows.Forms.PrintPreviewControl()
        Me.lblPreview = New System.Windows.Forms.Label()
        CType(Me.bndYourStyle, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.YourStyleDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CustomerInformationBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CustomisationBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.OrderSummaryBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pctPrinter, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'bndYourStyle
        '
        Me.bndYourStyle.DataSource = Me.YourStyleDataSet
        Me.bndYourStyle.Position = 0
        '
        'YourStyleDataSet
        '
        Me.YourStyleDataSet.DataSetName = "YourStyleDataSet"
        Me.YourStyleDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.CustomerIDDataGridViewTextBoxColumn, Me.CustomerNameDataGridViewTextBoxColumn, Me.AddressDataGridViewTextBoxColumn, Me.ContactNumberDataGridViewTextBoxColumn, Me.EmailDataGridViewTextBoxColumn, Me.OrderIDDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.CustomerInformationBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(12, 52)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 28
        Me.DataGridView1.Size = New System.Drawing.Size(740, 150)
        Me.DataGridView1.TabIndex = 0
        '
        'CustomerIDDataGridViewTextBoxColumn
        '
        Me.CustomerIDDataGridViewTextBoxColumn.DataPropertyName = "Customer ID"
        Me.CustomerIDDataGridViewTextBoxColumn.HeaderText = "Customer ID"
        Me.CustomerIDDataGridViewTextBoxColumn.Name = "CustomerIDDataGridViewTextBoxColumn"
        '
        'CustomerNameDataGridViewTextBoxColumn
        '
        Me.CustomerNameDataGridViewTextBoxColumn.DataPropertyName = "Customer Name"
        Me.CustomerNameDataGridViewTextBoxColumn.HeaderText = "Customer Name"
        Me.CustomerNameDataGridViewTextBoxColumn.Name = "CustomerNameDataGridViewTextBoxColumn"
        '
        'AddressDataGridViewTextBoxColumn
        '
        Me.AddressDataGridViewTextBoxColumn.DataPropertyName = "Address"
        Me.AddressDataGridViewTextBoxColumn.HeaderText = "Address"
        Me.AddressDataGridViewTextBoxColumn.Name = "AddressDataGridViewTextBoxColumn"
        '
        'ContactNumberDataGridViewTextBoxColumn
        '
        Me.ContactNumberDataGridViewTextBoxColumn.DataPropertyName = "Contact Number"
        Me.ContactNumberDataGridViewTextBoxColumn.HeaderText = "Contact Number"
        Me.ContactNumberDataGridViewTextBoxColumn.Name = "ContactNumberDataGridViewTextBoxColumn"
        '
        'EmailDataGridViewTextBoxColumn
        '
        Me.EmailDataGridViewTextBoxColumn.DataPropertyName = "Email"
        Me.EmailDataGridViewTextBoxColumn.HeaderText = "Email"
        Me.EmailDataGridViewTextBoxColumn.Name = "EmailDataGridViewTextBoxColumn"
        '
        'OrderIDDataGridViewTextBoxColumn
        '
        Me.OrderIDDataGridViewTextBoxColumn.DataPropertyName = "Order ID"
        Me.OrderIDDataGridViewTextBoxColumn.HeaderText = "Order ID"
        Me.OrderIDDataGridViewTextBoxColumn.Name = "OrderIDDataGridViewTextBoxColumn"
        '
        'CustomerInformationBindingSource
        '
        Me.CustomerInformationBindingSource.DataMember = "Customer Information"
        Me.CustomerInformationBindingSource.DataSource = Me.bndYourStyle
        '
        'Customer_InformationTableAdapter
        '
        Me.Customer_InformationTableAdapter.ClearBeforeFill = True
        '
        'DataGridView2
        '
        Me.DataGridView2.AutoGenerateColumns = False
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.OrderIDDataGridViewTextBoxColumn1, Me.ModelDataGridViewTextBoxColumn, Me.QuarterColourDataGridViewTextBoxColumn, Me.VampColourDataGridViewTextBoxColumn, Me.EyestayColourDataGridViewTextBoxColumn, Me.HeelTabColourDataGridViewTextBoxColumn, Me.HeelBackCounterColourDataGridViewTextBoxColumn, Me.LacesColourDataGridViewTextBoxColumn, Me.LogoDataGridViewCheckBoxColumn, Me.Field1DataGridViewTextBoxColumn, Me.AddedTextDataGridViewCheckBoxColumn, Me.EditedTextDataGridViewTextBoxColumn})
        Me.DataGridView2.DataSource = Me.CustomisationBindingSource
        Me.DataGridView2.Location = New System.Drawing.Point(12, 237)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.RowTemplate.Height = 28
        Me.DataGridView2.Size = New System.Drawing.Size(750, 150)
        Me.DataGridView2.TabIndex = 1
        '
        'OrderIDDataGridViewTextBoxColumn1
        '
        Me.OrderIDDataGridViewTextBoxColumn1.DataPropertyName = "Order ID"
        Me.OrderIDDataGridViewTextBoxColumn1.HeaderText = "Order ID"
        Me.OrderIDDataGridViewTextBoxColumn1.Name = "OrderIDDataGridViewTextBoxColumn1"
        '
        'ModelDataGridViewTextBoxColumn
        '
        Me.ModelDataGridViewTextBoxColumn.DataPropertyName = "Model"
        Me.ModelDataGridViewTextBoxColumn.HeaderText = "Model"
        Me.ModelDataGridViewTextBoxColumn.Name = "ModelDataGridViewTextBoxColumn"
        '
        'QuarterColourDataGridViewTextBoxColumn
        '
        Me.QuarterColourDataGridViewTextBoxColumn.DataPropertyName = "Quarter Colour"
        Me.QuarterColourDataGridViewTextBoxColumn.HeaderText = "Quarter Colour"
        Me.QuarterColourDataGridViewTextBoxColumn.Name = "QuarterColourDataGridViewTextBoxColumn"
        '
        'VampColourDataGridViewTextBoxColumn
        '
        Me.VampColourDataGridViewTextBoxColumn.DataPropertyName = "Vamp Colour"
        Me.VampColourDataGridViewTextBoxColumn.HeaderText = "Vamp Colour"
        Me.VampColourDataGridViewTextBoxColumn.Name = "VampColourDataGridViewTextBoxColumn"
        '
        'EyestayColourDataGridViewTextBoxColumn
        '
        Me.EyestayColourDataGridViewTextBoxColumn.DataPropertyName = "Eyestay Colour"
        Me.EyestayColourDataGridViewTextBoxColumn.HeaderText = "Eyestay Colour"
        Me.EyestayColourDataGridViewTextBoxColumn.Name = "EyestayColourDataGridViewTextBoxColumn"
        '
        'HeelTabColourDataGridViewTextBoxColumn
        '
        Me.HeelTabColourDataGridViewTextBoxColumn.DataPropertyName = "Heel Tab Colour"
        Me.HeelTabColourDataGridViewTextBoxColumn.HeaderText = "Heel Tab Colour"
        Me.HeelTabColourDataGridViewTextBoxColumn.Name = "HeelTabColourDataGridViewTextBoxColumn"
        '
        'HeelBackCounterColourDataGridViewTextBoxColumn
        '
        Me.HeelBackCounterColourDataGridViewTextBoxColumn.DataPropertyName = "Heel/Back Counter Colour"
        Me.HeelBackCounterColourDataGridViewTextBoxColumn.HeaderText = "Heel/Back Counter Colour"
        Me.HeelBackCounterColourDataGridViewTextBoxColumn.Name = "HeelBackCounterColourDataGridViewTextBoxColumn"
        '
        'LacesColourDataGridViewTextBoxColumn
        '
        Me.LacesColourDataGridViewTextBoxColumn.DataPropertyName = "Laces Colour"
        Me.LacesColourDataGridViewTextBoxColumn.HeaderText = "Laces Colour"
        Me.LacesColourDataGridViewTextBoxColumn.Name = "LacesColourDataGridViewTextBoxColumn"
        '
        'LogoDataGridViewCheckBoxColumn
        '
        Me.LogoDataGridViewCheckBoxColumn.DataPropertyName = "Logo"
        Me.LogoDataGridViewCheckBoxColumn.HeaderText = "Logo"
        Me.LogoDataGridViewCheckBoxColumn.Name = "LogoDataGridViewCheckBoxColumn"
        '
        'Field1DataGridViewTextBoxColumn
        '
        Me.Field1DataGridViewTextBoxColumn.DataPropertyName = "Field1"
        Me.Field1DataGridViewTextBoxColumn.HeaderText = "Field1"
        Me.Field1DataGridViewTextBoxColumn.Name = "Field1DataGridViewTextBoxColumn"
        '
        'AddedTextDataGridViewCheckBoxColumn
        '
        Me.AddedTextDataGridViewCheckBoxColumn.DataPropertyName = "Added Text"
        Me.AddedTextDataGridViewCheckBoxColumn.HeaderText = "Added Text"
        Me.AddedTextDataGridViewCheckBoxColumn.Name = "AddedTextDataGridViewCheckBoxColumn"
        '
        'EditedTextDataGridViewTextBoxColumn
        '
        Me.EditedTextDataGridViewTextBoxColumn.DataPropertyName = "Edited Text"
        Me.EditedTextDataGridViewTextBoxColumn.HeaderText = "Edited Text"
        Me.EditedTextDataGridViewTextBoxColumn.Name = "EditedTextDataGridViewTextBoxColumn"
        '
        'CustomisationBindingSource
        '
        Me.CustomisationBindingSource.DataMember = "Customisation"
        Me.CustomisationBindingSource.DataSource = Me.bndYourStyle
        '
        'CustomisationTableAdapter
        '
        Me.CustomisationTableAdapter.ClearBeforeFill = True
        '
        'DataGridView3
        '
        Me.DataGridView3.AutoGenerateColumns = False
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView3.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.OrderIDDataGridViewTextBoxColumn2, Me.ShoeModelDataGridViewTextBoxColumn, Me.LogoDataGridViewCheckBoxColumn1, Me.DateOrderedDataGridViewTextBoxColumn, Me.ProvidedByCustomerDataGridViewCheckBoxColumn, Me.SizeDataGridViewTextBoxColumn, Me.StatusDataGridViewTextBoxColumn})
        Me.DataGridView3.DataSource = Me.OrderSummaryBindingSource
        Me.DataGridView3.Location = New System.Drawing.Point(12, 418)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.RowTemplate.Height = 28
        Me.DataGridView3.Size = New System.Drawing.Size(750, 150)
        Me.DataGridView3.TabIndex = 2
        '
        'OrderIDDataGridViewTextBoxColumn2
        '
        Me.OrderIDDataGridViewTextBoxColumn2.DataPropertyName = "Order ID"
        Me.OrderIDDataGridViewTextBoxColumn2.HeaderText = "Order ID"
        Me.OrderIDDataGridViewTextBoxColumn2.Name = "OrderIDDataGridViewTextBoxColumn2"
        '
        'ShoeModelDataGridViewTextBoxColumn
        '
        Me.ShoeModelDataGridViewTextBoxColumn.DataPropertyName = "Shoe Model"
        Me.ShoeModelDataGridViewTextBoxColumn.HeaderText = "Shoe Model"
        Me.ShoeModelDataGridViewTextBoxColumn.Name = "ShoeModelDataGridViewTextBoxColumn"
        '
        'LogoDataGridViewCheckBoxColumn1
        '
        Me.LogoDataGridViewCheckBoxColumn1.DataPropertyName = "Logo"
        Me.LogoDataGridViewCheckBoxColumn1.HeaderText = "Logo"
        Me.LogoDataGridViewCheckBoxColumn1.Name = "LogoDataGridViewCheckBoxColumn1"
        '
        'DateOrderedDataGridViewTextBoxColumn
        '
        Me.DateOrderedDataGridViewTextBoxColumn.DataPropertyName = "Date Ordered"
        Me.DateOrderedDataGridViewTextBoxColumn.HeaderText = "Date Ordered"
        Me.DateOrderedDataGridViewTextBoxColumn.Name = "DateOrderedDataGridViewTextBoxColumn"
        '
        'ProvidedByCustomerDataGridViewCheckBoxColumn
        '
        Me.ProvidedByCustomerDataGridViewCheckBoxColumn.DataPropertyName = "Provided by Customer"
        Me.ProvidedByCustomerDataGridViewCheckBoxColumn.HeaderText = "Provided by Customer"
        Me.ProvidedByCustomerDataGridViewCheckBoxColumn.Name = "ProvidedByCustomerDataGridViewCheckBoxColumn"
        '
        'SizeDataGridViewTextBoxColumn
        '
        Me.SizeDataGridViewTextBoxColumn.DataPropertyName = "Size"
        Me.SizeDataGridViewTextBoxColumn.HeaderText = "Size"
        Me.SizeDataGridViewTextBoxColumn.Name = "SizeDataGridViewTextBoxColumn"
        '
        'StatusDataGridViewTextBoxColumn
        '
        Me.StatusDataGridViewTextBoxColumn.DataPropertyName = "Status"
        Me.StatusDataGridViewTextBoxColumn.HeaderText = "Status"
        Me.StatusDataGridViewTextBoxColumn.Name = "StatusDataGridViewTextBoxColumn"
        '
        'OrderSummaryBindingSource
        '
        Me.OrderSummaryBindingSource.DataMember = "Order Summary"
        Me.OrderSummaryBindingSource.DataSource = Me.bndYourStyle
        '
        'Order_SummaryTableAdapter
        '
        Me.Order_SummaryTableAdapter.ClearBeforeFill = True
        '
        'pctPrinter
        '
        Me.pctPrinter.Image = CType(resources.GetObject("pctPrinter.Image"), System.Drawing.Image)
        Me.pctPrinter.Location = New System.Drawing.Point(777, 237)
        Me.pctPrinter.Name = "pctPrinter"
        Me.pctPrinter.Size = New System.Drawing.Size(234, 161)
        Me.pctPrinter.TabIndex = 3
        Me.pctPrinter.TabStop = False
        '
        'btnPrevious
        '
        Me.btnPrevious.Location = New System.Drawing.Point(777, 535)
        Me.btnPrevious.Name = "btnPrevious"
        Me.btnPrevious.Size = New System.Drawing.Size(99, 33)
        Me.btnPrevious.TabIndex = 4
        Me.btnPrevious.Text = "Previous"
        Me.btnPrevious.UseVisualStyleBackColor = True
        '
        'PrintDocument1
        '
        '
        'PrintPreviewControl1
        '
        Me.PrintPreviewControl1.Location = New System.Drawing.Point(777, 52)
        Me.PrintPreviewControl1.Name = "PrintPreviewControl1"
        Me.PrintPreviewControl1.Size = New System.Drawing.Size(261, 162)
        Me.PrintPreviewControl1.TabIndex = 5
        '
        'lblPreview
        '
        Me.lblPreview.AutoSize = True
        Me.lblPreview.Location = New System.Drawing.Point(773, 29)
        Me.lblPreview.Name = "lblPreview"
        Me.lblPreview.Size = New System.Drawing.Size(103, 20)
        Me.lblPreview.TabIndex = 6
        Me.lblPreview.Text = "Print Preview:"
        '
        'FrmCustomer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1240, 600)
        Me.Controls.Add(Me.lblPreview)
        Me.Controls.Add(Me.PrintPreviewControl1)
        Me.Controls.Add(Me.btnPrevious)
        Me.Controls.Add(Me.pctPrinter)
        Me.Controls.Add(Me.DataGridView3)
        Me.Controls.Add(Me.DataGridView2)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "FrmCustomer"
        Me.Text = " "
        CType(Me.bndYourStyle, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.YourStyleDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CustomerInformationBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CustomisationBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.OrderSummaryBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pctPrinter, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents bndYourStyle As BindingSource
    Friend WithEvents YourStyleDataSet As YourStyleDataSet
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents CustomerInformationBindingSource As BindingSource
    Friend WithEvents Customer_InformationTableAdapter As YourStyleDataSetTableAdapters.Customer_InformationTableAdapter
    Friend WithEvents CustomerIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CustomerNameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents AddressDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ContactNumberDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents EmailDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents OrderIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DataGridView2 As DataGridView
    Friend WithEvents CustomisationBindingSource As BindingSource
    Friend WithEvents CustomisationTableAdapter As YourStyleDataSetTableAdapters.CustomisationTableAdapter
    Friend WithEvents OrderIDDataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents ModelDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents QuarterColourDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents VampColourDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents EyestayColourDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents HeelTabColourDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents HeelBackCounterColourDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents LacesColourDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents LogoDataGridViewCheckBoxColumn As DataGridViewCheckBoxColumn
    Friend WithEvents Field1DataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents AddedTextDataGridViewCheckBoxColumn As DataGridViewCheckBoxColumn
    Friend WithEvents EditedTextDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DataGridView3 As DataGridView
    Friend WithEvents OrderSummaryBindingSource As BindingSource
    Friend WithEvents Order_SummaryTableAdapter As YourStyleDataSetTableAdapters.Order_SummaryTableAdapter
    Friend WithEvents OrderIDDataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents ShoeModelDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents LogoDataGridViewCheckBoxColumn1 As DataGridViewCheckBoxColumn
    Friend WithEvents DateOrderedDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ProvidedByCustomerDataGridViewCheckBoxColumn As DataGridViewCheckBoxColumn
    Friend WithEvents SizeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StatusDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents pctPrinter As PictureBox
    Friend WithEvents btnPrevious As Button
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
    Friend WithEvents PrintPreviewControl1 As PrintPreviewControl
    Friend WithEvents lblPreview As Label
End Class
