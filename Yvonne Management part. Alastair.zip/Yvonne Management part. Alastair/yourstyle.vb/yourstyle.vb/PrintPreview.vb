﻿Public Class FrmPrintPreview
    Private Sub PctPrinting_Click(sender As Object, e As EventArgs) Handles PctPrinting.Click
        ' i learned about the printer powerpack and how to use it here https://www.youtube.com/watch?v=82Kknh67_sU
    End Sub
End Class