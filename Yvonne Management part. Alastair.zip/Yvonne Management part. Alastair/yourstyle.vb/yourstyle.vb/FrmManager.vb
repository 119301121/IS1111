﻿Public Class FrmManager


    Private Sub pctCustomer_Click(sender As Object, e As EventArgs) Handles pctCustomer.Click
        FrmCustomer.Show()
        Me.Hide()
    End Sub


End Class