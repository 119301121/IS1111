﻿Public Class FrmManagerLogin
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        'we had to start half the project again. this is where im picking up from. 
        'declaring variables
        Dim strName As String = "Admin"
        Dim strPassword As String = "AccessBulliesMe"

        If txtName.Text = Nothing Then
            MsgBox("Please fill required fields")
        ElseIf txtPassword.Text = Nothing Then
            MsgBox("Please fill all required fields")
        End If

        If txtName.Text = strName And txtPassword.Text = strPassword Then
            FrmManager.Show()
            Me.Hide()
        Else
            MsgBox("Name or password is wrong")
            pctJack.Visible = True
            'jack doesnt understand how you got your password wrong
        End If
    End Sub

    Private Sub FrmManagerLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
