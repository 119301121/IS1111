﻿Public Class Form1
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        If txtName.Text = "Jim Woulfe" And txtPassword.Text = "Dairygold" Then
            'form2.ShowDialog()
        Else
            MsgBox("Sorry, The Username or Password was incorrect.", MsgBoxStyle.Critical, "Information")
        End If

        Dim intMinLen, intMaxLen As Integer
        'Assigning a value to each variable
        intMinLen = 3
        'Minimum amount of characters required
        intMaxLen = 10

        If Len(txtPassword.Text) < intMinLen Or Len(txtName.Text) > intMaxLen Then
            MessageBox.Show("Data Entry Error", "Insert between 3 and 10 characters")
            With txtPassword
                .Clear()
                .Focus()
            End With
        Else MessageBox.Show("Well done, you have entered the correct amount of characters")
        End If

    End Sub
End Class
