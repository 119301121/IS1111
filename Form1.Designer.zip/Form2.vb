﻿Public Class Form2
    Private Sub btnReturn_Click(sender As Object, e As EventArgs) Handles btnReturn.Click
        Me.Hide()
        Form1.Show()
    End Sub
End Class