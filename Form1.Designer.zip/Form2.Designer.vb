﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.lblEnter = New System.Windows.Forms.Label()
        Me.grpStatus = New System.Windows.Forms.GroupBox()
        Me.btnReturn = New System.Windows.Forms.Button()
        Me.rdoShipment = New System.Windows.Forms.RadioButton()
        Me.rdoShipped = New System.Windows.Forms.RadioButton()
        Me.rdoCustomized = New System.Windows.Forms.RadioButton()
        Me.rdoReturned = New System.Windows.Forms.RadioButton()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.grpStatus.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnUpdate
        '
        Me.btnUpdate.Font = New System.Drawing.Font("MS Reference Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpdate.Location = New System.Drawing.Point(618, 394)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(145, 42)
        Me.btnUpdate.TabIndex = 0
        Me.btnUpdate.Text = "Update Status"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'lblEnter
        '
        Me.lblEnter.AutoSize = True
        Me.lblEnter.Font = New System.Drawing.Font("MS Reference Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEnter.Location = New System.Drawing.Point(106, 57)
        Me.lblEnter.Name = "lblEnter"
        Me.lblEnter.Size = New System.Drawing.Size(228, 26)
        Me.lblEnter.TabIndex = 2
        Me.lblEnter.Text = "Enter Customer ID:"
        '
        'grpStatus
        '
        Me.grpStatus.Controls.Add(Me.rdoReturned)
        Me.grpStatus.Controls.Add(Me.rdoCustomized)
        Me.grpStatus.Controls.Add(Me.rdoShipped)
        Me.grpStatus.Controls.Add(Me.rdoShipment)
        Me.grpStatus.Font = New System.Drawing.Font("MS Reference Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpStatus.Location = New System.Drawing.Point(111, 129)
        Me.grpStatus.Name = "grpStatus"
        Me.grpStatus.Size = New System.Drawing.Size(460, 228)
        Me.grpStatus.TabIndex = 3
        Me.grpStatus.TabStop = False
        Me.grpStatus.Text = "Enter Status"
        '
        'btnReturn
        '
        Me.btnReturn.Font = New System.Drawing.Font("MS Reference Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReturn.Location = New System.Drawing.Point(90, 394)
        Me.btnReturn.Name = "btnReturn"
        Me.btnReturn.Size = New System.Drawing.Size(197, 42)
        Me.btnReturn.TabIndex = 4
        Me.btnReturn.Text = "Return to login"
        Me.btnReturn.UseVisualStyleBackColor = True
        '
        'rdoShipment
        '
        Me.rdoShipment.AutoSize = True
        Me.rdoShipment.Font = New System.Drawing.Font("MS Reference Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdoShipment.Location = New System.Drawing.Point(20, 44)
        Me.rdoShipment.Name = "rdoShipment"
        Me.rdoShipment.Size = New System.Drawing.Size(288, 30)
        Me.rdoShipment.TabIndex = 0
        Me.rdoShipment.TabStop = True
        Me.rdoShipment.Text = "Still awaiting shipment"
        Me.rdoShipment.UseVisualStyleBackColor = True
        '
        'rdoShipped
        '
        Me.rdoShipped.AutoSize = True
        Me.rdoShipped.Font = New System.Drawing.Font("MS Reference Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdoShipped.Location = New System.Drawing.Point(20, 93)
        Me.rdoShipped.Name = "rdoShipped"
        Me.rdoShipped.Size = New System.Drawing.Size(431, 30)
        Me.rdoShipped.TabIndex = 1
        Me.rdoShipped.TabStop = True
        Me.rdoShipped.Text = "Shipped and awaiting customization"
        Me.rdoShipped.UseVisualStyleBackColor = True
        '
        'rdoCustomized
        '
        Me.rdoCustomized.AutoSize = True
        Me.rdoCustomized.Font = New System.Drawing.Font("MS Reference Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdoCustomized.Location = New System.Drawing.Point(20, 139)
        Me.rdoCustomized.Name = "rdoCustomized"
        Me.rdoCustomized.Size = New System.Drawing.Size(337, 30)
        Me.rdoCustomized.TabIndex = 2
        Me.rdoCustomized.TabStop = True
        Me.rdoCustomized.Text = "Currently being customized"
        Me.rdoCustomized.UseVisualStyleBackColor = True
        '
        'rdoReturned
        '
        Me.rdoReturned.AutoSize = True
        Me.rdoReturned.Font = New System.Drawing.Font("MS Reference Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdoReturned.Location = New System.Drawing.Point(20, 183)
        Me.rdoReturned.Name = "rdoReturned"
        Me.rdoReturned.Size = New System.Drawing.Size(415, 30)
        Me.rdoReturned.TabIndex = 3
        Me.rdoReturned.TabStop = True
        Me.rdoReturned.Text = "Customized and returned to outlet"
        Me.rdoReturned.UseVisualStyleBackColor = True
        '
        'txtID
        '
        Me.txtID.Font = New System.Drawing.Font("MS Reference Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtID.Location = New System.Drawing.Point(360, 57)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(162, 32)
        Me.txtID.TabIndex = 5
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.txtID)
        Me.Controls.Add(Me.btnReturn)
        Me.Controls.Add(Me.grpStatus)
        Me.Controls.Add(Me.lblEnter)
        Me.Controls.Add(Me.btnUpdate)
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.grpStatus.ResumeLayout(False)
        Me.grpStatus.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnUpdate As Button
    Friend WithEvents lblEnter As Label
    Friend WithEvents grpStatus As GroupBox
    Friend WithEvents rdoReturned As RadioButton
    Friend WithEvents rdoCustomized As RadioButton
    Friend WithEvents rdoShipped As RadioButton
    Friend WithEvents rdoShipment As RadioButton
    Friend WithEvents btnReturn As Button
    Friend WithEvents txtID As TextBox
End Class
