﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.btnYes = New System.Windows.Forms.Button()
        Me.btnNO = New System.Windows.Forms.Button()
        Me.lblAccount = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblWelcome = New System.Windows.Forms.Label()
        Me.lblYourstyle = New System.Windows.Forms.Label()
        Me.lblCustomization = New System.Windows.Forms.Label()
        Me.txtUsername = New System.Windows.Forms.TextBox()
        Me.lblUsername = New System.Windows.Forms.Label()
        Me.lblPassword = New System.Windows.Forms.Label()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.txtCusername = New System.Windows.Forms.TextBox()
        Me.lblCusername = New System.Windows.Forms.Label()
        Me.txtCpassword = New System.Windows.Forms.TextBox()
        Me.lblCpassword = New System.Windows.Forms.Label()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.btnBack1 = New System.Windows.Forms.Button()
        Me.btnContinue = New System.Windows.Forms.Button()
        Me.btnContinue1 = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnClear1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnYes
        '
        Me.btnYes.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnYes.Font = New System.Drawing.Font("MV Boli", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnYes.Location = New System.Drawing.Point(384, 272)
        Me.btnYes.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnYes.Name = "btnYes"
        Me.btnYes.Size = New System.Drawing.Size(100, 38)
        Me.btnYes.TabIndex = 0
        Me.btnYes.Text = "Yes"
        Me.btnYes.UseVisualStyleBackColor = False
        '
        'btnNO
        '
        Me.btnNO.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnNO.Font = New System.Drawing.Font("MV Boli", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNO.Location = New System.Drawing.Point(569, 272)
        Me.btnNO.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnNO.Name = "btnNO"
        Me.btnNO.Size = New System.Drawing.Size(100, 39)
        Me.btnNO.TabIndex = 1
        Me.btnNO.Text = "No"
        Me.btnNO.UseVisualStyleBackColor = False
        '
        'lblAccount
        '
        Me.lblAccount.AutoSize = True
        Me.lblAccount.BackColor = System.Drawing.Color.Transparent
        Me.lblAccount.Font = New System.Drawing.Font("MV Boli", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAccount.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.lblAccount.Location = New System.Drawing.Point(300, 202)
        Me.lblAccount.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblAccount.Name = "lblAccount"
        Me.lblAccount.Size = New System.Drawing.Size(428, 34)
        Me.lblAccount.TabIndex = 2
        Me.lblAccount.Text = "Have you an account with us?"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(403, 46)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(0, 17)
        Me.Label2.TabIndex = 3
        '
        'lblWelcome
        '
        Me.lblWelcome.AutoSize = True
        Me.lblWelcome.BackColor = System.Drawing.Color.Transparent
        Me.lblWelcome.Font = New System.Drawing.Font("MV Boli", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWelcome.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.lblWelcome.Location = New System.Drawing.Point(433, 11)
        Me.lblWelcome.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblWelcome.Name = "lblWelcome"
        Me.lblWelcome.Size = New System.Drawing.Size(189, 34)
        Me.lblWelcome.TabIndex = 4
        Me.lblWelcome.Text = "Welcome To "
        '
        'lblYourstyle
        '
        Me.lblYourstyle.AutoSize = True
        Me.lblYourstyle.BackColor = System.Drawing.Color.Transparent
        Me.lblYourstyle.Font = New System.Drawing.Font("Script MT Bold", 21.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblYourstyle.ForeColor = System.Drawing.Color.Aquamarine
        Me.lblYourstyle.Location = New System.Drawing.Point(432, 58)
        Me.lblYourstyle.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblYourstyle.Name = "lblYourstyle"
        Me.lblYourstyle.Size = New System.Drawing.Size(182, 44)
        Me.lblYourstyle.TabIndex = 5
        Me.lblYourstyle.Text = "Your Style"
        '
        'lblCustomization
        '
        Me.lblCustomization.AutoSize = True
        Me.lblCustomization.BackColor = System.Drawing.Color.Transparent
        Me.lblCustomization.Font = New System.Drawing.Font("MV Boli", 15.75!, CType(((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic) _
                Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCustomization.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.lblCustomization.Location = New System.Drawing.Point(205, 127)
        Me.lblCustomization.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblCustomization.Name = "lblCustomization"
        Me.lblCustomization.Size = New System.Drawing.Size(605, 34)
        Me.lblCustomization.TabIndex = 6
        Me.lblCustomization.Text = "A Shoe Customization Shop Like No Other"
        '
        'txtUsername
        '
        Me.txtUsername.Font = New System.Drawing.Font("MV Boli", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUsername.Location = New System.Drawing.Point(384, 358)
        Me.txtUsername.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(284, 50)
        Me.txtUsername.TabIndex = 7
        '
        'lblUsername
        '
        Me.lblUsername.AutoSize = True
        Me.lblUsername.BackColor = System.Drawing.Color.Transparent
        Me.lblUsername.Font = New System.Drawing.Font("MV Boli", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUsername.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.lblUsername.Location = New System.Drawing.Point(36, 362)
        Me.lblUsername.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblUsername.Name = "lblUsername"
        Me.lblUsername.Size = New System.Drawing.Size(308, 34)
        Me.lblUsername.TabIndex = 8
        Me.lblUsername.Text = "Enter Your Username"
        '
        'lblPassword
        '
        Me.lblPassword.AutoSize = True
        Me.lblPassword.BackColor = System.Drawing.Color.Transparent
        Me.lblPassword.Font = New System.Drawing.Font("MV Boli", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPassword.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.lblPassword.Location = New System.Drawing.Point(43, 471)
        Me.lblPassword.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblPassword.Name = "lblPassword"
        Me.lblPassword.Size = New System.Drawing.Size(303, 34)
        Me.lblPassword.TabIndex = 9
        Me.lblPassword.Text = "Enter Your Password"
        '
        'txtPassword
        '
        Me.txtPassword.Font = New System.Drawing.Font("MV Boli", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPassword.Location = New System.Drawing.Point(384, 471)
        Me.txtPassword.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(284, 50)
        Me.txtPassword.TabIndex = 10
        '
        'txtCusername
        '
        Me.txtCusername.Font = New System.Drawing.Font("MV Boli", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCusername.Location = New System.Drawing.Point(384, 415)
        Me.txtCusername.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtCusername.Name = "txtCusername"
        Me.txtCusername.Size = New System.Drawing.Size(284, 50)
        Me.txtCusername.TabIndex = 11
        '
        'lblCusername
        '
        Me.lblCusername.AutoSize = True
        Me.lblCusername.BackColor = System.Drawing.Color.Transparent
        Me.lblCusername.Font = New System.Drawing.Font("MV Boli", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCusername.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.lblCusername.Location = New System.Drawing.Point(24, 418)
        Me.lblCusername.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblCusername.Name = "lblCusername"
        Me.lblCusername.Size = New System.Drawing.Size(320, 34)
        Me.lblCusername.TabIndex = 12
        Me.lblCusername.Text = "Create Your Username"
        '
        'txtCpassword
        '
        Me.txtCpassword.Font = New System.Drawing.Font("MV Boli", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCpassword.Location = New System.Drawing.Point(384, 528)
        Me.txtCpassword.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtCpassword.Name = "txtCpassword"
        Me.txtCpassword.Size = New System.Drawing.Size(284, 50)
        Me.txtCpassword.TabIndex = 13
        '
        'lblCpassword
        '
        Me.lblCpassword.AutoSize = True
        Me.lblCpassword.BackColor = System.Drawing.Color.Transparent
        Me.lblCpassword.Font = New System.Drawing.Font("MV Boli", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCpassword.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.lblCpassword.Location = New System.Drawing.Point(16, 532)
        Me.lblCpassword.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblCpassword.Name = "lblCpassword"
        Me.lblCpassword.Size = New System.Drawing.Size(329, 34)
        Me.lblCpassword.TabIndex = 14
        Me.lblCpassword.Text = "Create  Your Password"
        '
        'btnBack
        '
        Me.btnBack.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnBack.Font = New System.Drawing.Font("MV Boli", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.Location = New System.Drawing.Point(384, 612)
        Me.btnBack.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(100, 38)
        Me.btnBack.TabIndex = 15
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = False
        '
        'btnBack1
        '
        Me.btnBack1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnBack1.Font = New System.Drawing.Font("MV Boli", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack1.Location = New System.Drawing.Point(569, 612)
        Me.btnBack1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnBack1.Name = "btnBack1"
        Me.btnBack1.Size = New System.Drawing.Size(100, 38)
        Me.btnBack1.TabIndex = 16
        Me.btnBack1.Text = "Back"
        Me.btnBack1.UseVisualStyleBackColor = False
        '
        'btnContinue
        '
        Me.btnContinue.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnContinue.Font = New System.Drawing.Font("MV Boli", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnContinue.Location = New System.Drawing.Point(848, 358)
        Me.btnContinue.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnContinue.Name = "btnContinue"
        Me.btnContinue.Size = New System.Drawing.Size(147, 50)
        Me.btnContinue.TabIndex = 17
        Me.btnContinue.Text = "Continue"
        Me.btnContinue.UseVisualStyleBackColor = False
        '
        'btnContinue1
        '
        Me.btnContinue1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnContinue1.Font = New System.Drawing.Font("MV Boli", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnContinue1.Location = New System.Drawing.Point(848, 415)
        Me.btnContinue1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnContinue1.Name = "btnContinue1"
        Me.btnContinue1.Size = New System.Drawing.Size(147, 50)
        Me.btnContinue1.TabIndex = 18
        Me.btnContinue1.Text = "Continue"
        Me.btnContinue1.UseVisualStyleBackColor = False
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnClear.Font = New System.Drawing.Font("MV Boli", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(848, 471)
        Me.btnClear.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(147, 50)
        Me.btnClear.TabIndex = 19
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'btnClear1
        '
        Me.btnClear1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnClear1.Font = New System.Drawing.Font("MV Boli", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear1.Location = New System.Drawing.Point(848, 528)
        Me.btnClear1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnClear1.Name = "btnClear1"
        Me.btnClear1.Size = New System.Drawing.Size(147, 50)
        Me.btnClear1.TabIndex = 20
        Me.btnClear1.Text = "Clear"
        Me.btnClear1.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1109, 699)
        Me.Controls.Add(Me.btnClear1)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnContinue1)
        Me.Controls.Add(Me.btnContinue)
        Me.Controls.Add(Me.btnBack1)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.lblCpassword)
        Me.Controls.Add(Me.txtCpassword)
        Me.Controls.Add(Me.lblCusername)
        Me.Controls.Add(Me.txtCusername)
        Me.Controls.Add(Me.txtPassword)
        Me.Controls.Add(Me.lblPassword)
        Me.Controls.Add(Me.lblUsername)
        Me.Controls.Add(Me.txtUsername)
        Me.Controls.Add(Me.lblCustomization)
        Me.Controls.Add(Me.lblYourstyle)
        Me.Controls.Add(Me.lblWelcome)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblAccount)
        Me.Controls.Add(Me.btnNO)
        Me.Controls.Add(Me.btnYes)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnYes As Button
    Friend WithEvents btnNO As Button
    Friend WithEvents lblAccount As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblWelcome As Label
    Friend WithEvents lblYourstyle As Label
    Friend WithEvents lblCustomization As Label
    Friend WithEvents txtUsername As TextBox
    Friend WithEvents lblUsername As Label
    Friend WithEvents lblPassword As Label
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents txtCusername As TextBox
    Friend WithEvents lblCusername As Label
    Friend WithEvents txtCpassword As TextBox
    Friend WithEvents lblCpassword As Label
    Friend WithEvents btnBack As Button
    Friend WithEvents btnBack1 As Button
    Friend WithEvents btnContinue As Button
    Friend WithEvents btnContinue1 As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnClear1 As Button
End Class
