﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnYes.Click
        txtPassword.Show()
        txtUsername.Show()
        lblPassword.Show()
        lblUsername.Show()
        btnBack.Show()
        btnContinue.Show()
        btnClear.Show()
        btnNO.Hide()
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles lblCustomization.Click

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtPassword.Visible = False
        txtUsername.Visible = False
        lblPassword.Visible = False
        lblUsername.Visible = False
        btnBack.Visible = False
        btnContinue.Visible = False
        btnClear.Visible = False
        txtCpassword.Visible = False
        txtCusername.Visible = False
        lblCpassword.Visible = False
        lblCusername.Visible = False
        btnBack1.Visible = False
        btnContinue1.Visible = False
        btnClear1.Visible = False
    End Sub

    Private Sub btnNO_Click(sender As Object, e As EventArgs) Handles btnNO.Click
        txtCpassword.Show()
        txtCusername.Show()
        lblCpassword.Show()
        lblCusername.Show()
        btnBack1.Show()
        btnContinue1.Show()
        btnClear1.Show()
        btnYes.Hide()
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        txtPassword.Hide()
        txtUsername.Hide()
        lblPassword.Hide()
        lblUsername.Hide()
        btnBack.Hide()
        btnContinue.Hide()
        btnClear.Hide()
        btnNO.Show()
        btnYes.Show()
    End Sub

    Private Sub btnBack1_Click(sender As Object, e As EventArgs) Handles btnBack1.Click
        txtCpassword.Hide()
        txtCusername.Hide()
        lblCpassword.Hide()
        lblCusername.Hide()
        btnBack1.Hide()
        btnContinue1.Hide()
        btnClear1.Hide()
        btnYes.Show()
    End Sub

    Private Sub btnContinue_Click(sender As Object, e As EventArgs) Handles btnContinue.Click
        If txtUsername.Text = "username" And txtPassword.Text = "password" Then
            'Form2.ShowDialog()
        Else
            MsgBox("Sorry, The Username or Password was incorrect.", MsgBoxStyle.Critical, "Information")
        End If

        Dim intMinLen, intMaxLen As Integer
        'Assigning a value to each variable
        intMinLen = 3
        'Minimum amount of characters required
        intMaxLen = 10

        If Len(txtPassword.Text) < intMinLen Or Len(txtUsername.Text) > intMaxLen Then
            MessageBox.Show("Data Entry Error", "Insert between 3 and 10 characters")
            With txtPassword
                .Clear()
                .Focus()
            End With
        Else MessageBox.Show("Well done, you have entered the correct amount of characters")
        End If


    End Sub

    Private Sub btnContinue1_Click(sender As Object, e As EventArgs) Handles btnContinue1.Click
        txtCpassword.Hide()
        txtCusername.Hide()
        lblCpassword.Hide()
        lblCusername.Hide()
        btnBack1.Hide()
        btnContinue1.Hide()
        btnClear1.Hide()
        txtPassword.Show()
        txtUsername.Show()
        lblPassword.Show()
        lblUsername.Show()
        btnBack.Show()
        btnContinue.Show()
        btnClear.Show()
        btnNO.Hide()

        Dim intMinLen, intMaxLen As Integer
        'Assigning a value to each variable
        intMinLen = 3
        'Minimum amount of characters required
        intMaxLen = 10

        If Len(txtPassword.Text) < intMinLen Or Len(txtUsername.Text) > intMaxLen Then
            MessageBox.Show("Data Entry Error", "Insert between 3 and 10 characters")
            With txtPassword
                .Clear()
                .Focus()
            End With
        Else MessageBox.Show("Well done, you have entered the correct amount of characters")
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtPassword.Clear()
        txtUsername.Clear()
    End Sub

    Private Sub btnClear1_Click(sender As Object, e As EventArgs) Handles btnClear1.Click
        txtCpassword.Clear()
        txtCusername.Clear()
    End Sub
End Class
