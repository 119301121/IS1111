﻿Public Class Frmprinter
    Private Sub printer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'I didnt know how to make this part work and youtube didnt help
    End Sub
End Class